// Store-wide currency + pricing rules (Bangladeshi Taka, Bangla digits)
export const FREE_SHIPPING_THRESHOLD = 5000; // ৳ — free shipping above this subtotal
export const SHIPPING_FEE = 120; // ৳ — flat shipping fee
export const TAX_RATE = 0.08; // 8%

const bnNumber = new Intl.NumberFormat('bn-BD', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

/** 1250 -> "৳১,২৫০" */
export const formatTaka = (amount: number): string => '৳' + bnNumber.format(Number.isFinite(amount) ? amount : 0);

/** Shared totals calculation used by the cart drawer and the checkout. */
export function calcTotals(subtotal: number, discount: number) {
  const safeDiscount = Math.min(Math.max(discount, 0), subtotal);
  const afterDiscount = subtotal - safeDiscount;
  const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  const tax = afterDiscount * TAX_RATE;
  const total = Math.max(0, afterDiscount + shipping + tax);
  return { discount: safeDiscount, shipping, tax, total };
}
