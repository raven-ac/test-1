export type UserRole = 'customer' | 'admin';

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  photoURL: string;
  phone?: string;
  role: UserRole;
  createdAt: string;
  updatedAt: string;
}

export interface UserAddress {
  id: string;
  userId: string;
  recipientName: string;
  street: string;
  apartment?: string;
  city: string;
  state?: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
  createdAt: string;
}

export interface WishlistItem {
  id: string;
  userId: string;
  productId: string;
  addedAt: string;
}

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  price: number;
  image: string;
  size: string;
  quantity: number;
  category: string;
}

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  size: string;
  quantity: number;
  image?: string;
}

export interface Order {
  id: string;
  userId: string;
  customerEmail: string;
  customerName: string;
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  discount?: number;
  couponCode?: string;
  status: OrderStatus;
  shippingAddress: string;
  createdAt: string;
  updatedAt: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  category: 'outerwear' | 'tops' | 'bottoms' | 'accessories' | 'footwear';
  price: number;
  description: string;
  details: string;
  images: string[];
  sizes: string[];
  stock: number;
  featured: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AdminEmailRecord {
  email: string;
  addedBy?: string;
  addedAt: string;
  notes?: string;
}


export type CouponType = 'percent' | 'fixed';

export interface Coupon {
  code: string; // also the Firestore document id (UPPERCASE)
  type: CouponType;
  value: number; // percent (1-100) or fixed amount in ৳
  minOrder: number; // minimum subtotal in ৳ (0 = none)
  maxUses: number; // 0 = unlimited
  usedCount: number;
  expiresAt: string; // ISO date, '' = never
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export type PaymentStatus = 'submitted' | 'verified' | 'rejected';

export interface PaymentSubmission {
  id: string;
  orderId: string;
  sender: string;
  trxid: string;
  amount: number;
  method: string;
  status: PaymentStatus;
  createdAt: string;
}
