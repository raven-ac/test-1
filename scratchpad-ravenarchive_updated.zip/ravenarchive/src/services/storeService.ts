import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  increment
} from 'firebase/firestore';
import { db } from '../firebase/config.ts';
import { handleFirestoreError, OperationType } from '../firebase/errors.ts';
import { Product, Order, UserAddress, WishlistItem, OrderStatus, UserProfile, Coupon, PaymentSubmission, PaymentStatus } from '../types.ts';
import { INITIAL_PRODUCTS } from '../data/mockProducts.ts';

// Cache for products if offline or fallback
let localProductsCache: Product[] = [...INITIAL_PRODUCTS];

// --- PRODUCT SERVICES ---
export async function getProducts(): Promise<Product[]> {
  try {
    const productsRef = collection(db, 'products');
    const snapshot = await getDocs(productsRef);
    if (snapshot.empty) {
      // Seed products on first run into local state and Firestore if permitted
      return INITIAL_PRODUCTS;
    }
    const products: Product[] = [];
    snapshot.forEach(docSnap => {
      products.push(docSnap.data() as Product);
    });
    localProductsCache = products;
    return products;
  } catch (error) {
    console.warn('Failed to fetch products from Firestore, falling back to local catalog:', error);
    return localProductsCache;
  }
}

export async function createProduct(product: Product): Promise<void> {
  const path = `products/${product.id}`;
  try {
    await setDoc(doc(db, 'products', product.id), product);
    localProductsCache.unshift(product);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<void> {
  const path = `products/${id}`;
  try {
    const now = new Date().toISOString();
    await updateDoc(doc(db, 'products', id), {
      ...updates,
      updatedAt: now,
    });
    localProductsCache = localProductsCache.map(p => p.id === id ? { ...p, ...updates, updatedAt: now } : p);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteProduct(id: string): Promise<void> {
  const path = `products/${id}`;
  try {
    await deleteDoc(doc(db, 'products', id));
    localProductsCache = localProductsCache.filter(p => p.id !== id);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// --- ORDER SERVICES ---
export async function createOrder(order: Order): Promise<void> {
  const path = `orders/${order.id}`;
  try {
    await setDoc(doc(db, 'orders', order.id), order);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function getOrdersForUser(userId: string): Promise<Order[]> {
  const path = 'orders';
  try {
    const q = query(
      collection(db, 'orders'),
      where('userId', '==', userId)
    );
    const snap = await getDocs(q);
    const orders: Order[] = [];
    snap.forEach(d => {
      orders.push(d.data() as Order);
    });
    // Sort client-side by date descending
    return orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function getAllOrders(): Promise<Order[]> {
  const path = 'orders';
  try {
    const snap = await getDocs(collection(db, 'orders'));
    const orders: Order[] = [];
    snap.forEach(d => {
      orders.push(d.data() as Order);
    });
    return orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function updateOrderStatus(orderId: string, status: OrderStatus): Promise<void> {
  const path = `orders/${orderId}`;
  try {
    const now = new Date().toISOString();
    await updateDoc(doc(db, 'orders', orderId), {
      status,
      updatedAt: now
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// --- ADDRESS SERVICES ---
export async function getUserAddresses(userId: string): Promise<UserAddress[]> {
  const path = `users/${userId}/addresses`;
  try {
    const snap = await getDocs(collection(db, 'users', userId, 'addresses'));
    const addresses: UserAddress[] = [];
    snap.forEach(d => {
      addresses.push(d.data() as UserAddress);
    });
    return addresses;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function saveUserAddress(userId: string, address: UserAddress): Promise<void> {
  const path = `users/${userId}/addresses/${address.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'addresses', address.id), address);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteUserAddress(userId: string, addressId: string): Promise<void> {
  const path = `users/${userId}/addresses/${addressId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'addresses', addressId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// --- WISHLIST SERVICES ---
export async function getUserWishlist(userId: string): Promise<string[]> {
  const path = `users/${userId}/wishlist`;
  try {
    const snap = await getDocs(collection(db, 'users', userId, 'wishlist'));
    const productIds: string[] = [];
    snap.forEach(d => {
      const data = d.data() as WishlistItem;
      productIds.push(data.productId);
    });
    return productIds;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function addToWishlist(userId: string, productId: string): Promise<void> {
  const path = `users/${userId}/wishlist/${productId}`;
  try {
    const item: WishlistItem = {
      id: productId,
      userId,
      productId,
      addedAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'users', userId, 'wishlist', productId), item);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function removeFromWishlist(userId: string, productId: string): Promise<void> {
  const path = `users/${userId}/wishlist/${productId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'wishlist', productId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// --- CUSTOMERS / USERS (ADMIN) ---
export async function getAllCustomers(): Promise<UserProfile[]> {
  const path = 'users';
  try {
    const snap = await getDocs(collection(db, 'users'));
    const users: UserProfile[] = [];
    snap.forEach(d => {
      users.push(d.data() as UserProfile);
    });
    return users;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

// --- AUTHORIZED ADMIN EMAILS MANAGEMENT ---
export async function getAdminEmails(): Promise<{ email: string; addedBy?: string; addedAt: string; notes?: string }[]> {
  const path = 'admin_emails';
  try {
    const snap = await getDocs(collection(db, 'admin_emails'));
    const records: { email: string; addedBy?: string; addedAt: string; notes?: string }[] = [];
    snap.forEach(d => {
      records.push(d.data() as any);
    });
    return records;
  } catch (err) {
    console.warn('Could not list admin_emails:', err);
    return [];
  }
}

export async function addAdminEmail(email: string, addedBy: string, notes?: string): Promise<void> {
  const cleanEmail = email.trim().toLowerCase();
  const path = `admin_emails/${cleanEmail}`;
  const record = {
    email: cleanEmail,
    addedBy,
    addedAt: new Date().toISOString(),
    notes: notes?.trim() || 'Co-Administrator',
  };
  try {
    await setDoc(doc(db, 'admin_emails', cleanEmail), record);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function removeAdminEmail(email: string): Promise<void> {
  const cleanEmail = email.trim().toLowerCase();
  const path = `admin_emails/${cleanEmail}`;
  try {
    await deleteDoc(doc(db, 'admin_emails', cleanEmail));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function checkIsAdminEmail(email: string): Promise<boolean> {
  if (!email) return false;
  try {
    const cleanEmail = email.trim().toLowerCase();
    const snap = await getDoc(doc(db, 'admin_emails', cleanEmail));
    return snap.exists();
  } catch {
    return false;
  }
}



// --- COUPONS ---
export const normalizeCode = (code: string) => code.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');

export async function getAllCoupons(): Promise<Coupon[]> {
  const path = 'coupons';
  try {
    const snap = await getDocs(collection(db, 'coupons'));
    const list: Coupon[] = [];
    snap.forEach(d => list.push(d.data() as Coupon));
    return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function saveCoupon(coupon: Coupon): Promise<void> {
  const path = `coupons/${coupon.code}`;
  try {
    await setDoc(doc(db, 'coupons', coupon.code), coupon);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function setCouponActive(code: string, active: boolean): Promise<void> {
  const path = `coupons/${code}`;
  try {
    await updateDoc(doc(db, 'coupons', code), { active, updatedAt: new Date().toISOString() });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteCoupon(code: string): Promise<void> {
  const path = `coupons/${code}`;
  try {
    await deleteDoc(doc(db, 'coupons', code));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

/** Returns the coupon, or throws an Error with a Bangla message the customer can read. */
export async function validateCoupon(rawCode: string, subtotal: number): Promise<Coupon> {
  const code = normalizeCode(rawCode);
  if (!code) throw new Error('কুপন কোড লিখুন');
  let coupon: Coupon | null = null;
  try {
    const snap = await getDoc(doc(db, 'coupons', code));
    coupon = snap.exists() ? (snap.data() as Coupon) : null;
  } catch {
    throw new Error('কুপন যাচাই করা যায়নি, আবার চেষ্টা করুন');
  }
  if (!coupon || !coupon.active) throw new Error('কুপন কোডটি সঠিক নয়');
  if (coupon.expiresAt && new Date(coupon.expiresAt).getTime() < Date.now()) throw new Error('কুপনটির মেয়াদ শেষ হয়ে গেছে');
  if (coupon.maxUses > 0 && coupon.usedCount >= coupon.maxUses) throw new Error('কুপনটির ব্যবহারের সীমা শেষ');
  if (coupon.minOrder > 0 && subtotal < coupon.minOrder) throw new Error(`এই কুপনের জন্য সর্বনিম্ন অর্ডার ${coupon.minOrder} টাকা`);
  return coupon;
}

export function couponDiscount(coupon: Coupon | null, subtotal: number): number {
  if (!coupon) return 0;
  const raw = coupon.type === 'percent' ? (subtotal * coupon.value) / 100 : coupon.value;
  return Math.min(Math.max(raw, 0), subtotal);
}

export const couponUsageUpdate = () => ({ usedCount: increment(1), updatedAt: new Date().toISOString() });

// --- MANUAL PAYMENT SUBMISSIONS (written by /pay/:id, reviewed by admin) ---
export async function getAllPayments(): Promise<PaymentSubmission[]> {
  const path = 'payments';
  try {
    const snap = await getDocs(collection(db, 'payments'));
    const list: PaymentSubmission[] = [];
    snap.forEach(d => list.push(d.data() as PaymentSubmission));
    return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function updatePaymentStatus(id: string, status: PaymentStatus): Promise<void> {
  const path = `payments/${id}`;
  try {
    await updateDoc(doc(db, 'payments', id), { status });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}
