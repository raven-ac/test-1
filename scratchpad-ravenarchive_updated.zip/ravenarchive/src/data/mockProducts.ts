import { Product } from '../types.ts';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: "rvn-out-01",
    name: "Obsidian Modular Parka",
    slug: "obsidian-modular-parka",
    category: "outerwear",
    price: 490,
    description: "Architectural silhouette crafted from waterproof Japanese memory nylon. Features magnetic fidlock closures, concealable storm hood, and articulated sleeves.",
    details: "100% Japanese High-Density Nylon. Water-repellent DWR coating. YKK Aquaguard zippers. Made in Portugal.",
    images: [
      "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1516257984-b1b4d707412e?auto=format&fit=crop&w=1200&q=80"
    ],
    sizes: ["S", "M", "L", "XL"],
    stock: 14,
    featured: true,
    createdAt: "2026-01-15T00:00:00.000Z",
    updatedAt: "2026-01-15T00:00:00.000Z"
  },
  {
    id: "rvn-top-01",
    name: "Monolith Raw-Edge Hoodie",
    slug: "monolith-raw-edge-hoodie",
    category: "tops",
    price: 240,
    description: "600 GSM organic French terry. Dropped shoulder boxy cut with subtle distressed raw hems, heavy dual-layer hood, and concealed side seam pockets.",
    details: "100% GOTS Certified Organic Cotton. Pigment cold-dyed in charcoal obsidian. Custom woven label.",
    images: [
      "https://images.unsplash.com/photo-1509967419530-da38b4704bc6?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=1200&q=80"
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    stock: 28,
    featured: true,
    createdAt: "2026-01-18T00:00:00.000Z",
    updatedAt: "2026-01-18T00:00:00.000Z"
  },
  {
    id: "rvn-bot-01",
    name: "Architect Tactical Trousers",
    slug: "architect-tactical-trousers",
    category: "bottoms",
    price: 320,
    description: "Relaxed ergonomic silhouette engineered with 3D darting at knee joints, adjustable cobra buckle cuffs, and low-profile gusseted cargo compartments.",
    details: "65% Cotton, 35% Technical Polyamide. Teflon stain-resistant finish. Anodized matte black hardware.",
    images: [
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=1200&q=80"
    ],
    sizes: ["28", "30", "32", "34", "36"],
    stock: 19,
    featured: true,
    createdAt: "2026-02-01T00:00:00.000Z",
    updatedAt: "2026-02-01T00:00:00.000Z"
  },
  {
    id: "rvn-out-02",
    name: "Void Asymmetric Trench Coat",
    slug: "void-asymmetric-trench-coat",
    category: "outerwear",
    price: 680,
    description: "Deconstructed double-breasted trench in heavyweight brushed twill. Features oversized storm flaps, removable waist sash, and raw finished lapels.",
    details: "Heavyweight Cotton Twill with Cupro lining. Horn buttons. Oversized relaxed drape.",
    images: [
      "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80"
    ],
    sizes: ["S", "M", "L"],
    stock: 8,
    featured: false,
    createdAt: "2026-02-05T00:00:00.000Z",
    updatedAt: "2026-02-05T00:00:00.000Z"
  },
  {
    id: "rvn-top-02",
    name: "Cyber-Knit Seamless Sweater",
    slug: "cyber-knit-seamless-sweater",
    category: "tops",
    price: 270,
    description: "3D tubular knit construction without seams for continuous motion. Blends extrafine merino wool with thermal nylon yarn.",
    details: "70% Merino Wool, 30% Cordura Nylon. Ribbed funnel collar. Thumbhole detailing.",
    images: [
      "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=1200&q=80"
    ],
    sizes: ["S", "M", "L", "XL"],
    stock: 22,
    featured: false,
    createdAt: "2026-02-10T00:00:00.000Z",
    updatedAt: "2026-02-10T00:00:00.000Z"
  },
  {
    id: "rvn-acc-01",
    name: "Titanium Carabiner Hardware Belt",
    slug: "titanium-carabiner-belt",
    category: "accessories",
    price: 130,
    description: "Industrial seatbelt webbing strap paired with laser-engraved aircraft-grade matte black carabiner buckle and quick-release lever.",
    details: "Mil-spec nylon webbing. Grade 5 Titanium alloy clip. Length 135cm (adjustable).",
    images: [
      "https://images.unsplash.com/photo-1624222247344-550fb60583dc?auto=format&fit=crop&w=1200&q=80"
    ],
    sizes: ["ONE SIZE"],
    stock: 45,
    featured: true,
    createdAt: "2026-02-12T00:00:00.000Z",
    updatedAt: "2026-02-12T00:00:00.000Z"
  },
  {
    id: "rvn-foot-01",
    name: "Vandal Lug-Sole Chelsea Boot",
    slug: "vandal-lug-sole-chelsea",
    category: "footwear",
    price: 520,
    description: "Matte full-grain Italian calfskin with an exaggerated sculpted Vibram lug sole. Double elastic gusset with debossed RAVEN pull tabs.",
    details: "Full grain vegetable-tanned leather. Custom chunky Vibram rubber tread. Handcrafted in Italy.",
    images: [
      "https://images.unsplash.com/photo-1582844256061-825595304910?auto=format&fit=crop&w=1200&q=80"
    ],
    sizes: ["40", "41", "42", "43", "44", "45"],
    stock: 12,
    featured: true,
    createdAt: "2026-02-15T00:00:00.000Z",
    updatedAt: "2026-02-15T00:00:00.000Z"
  },
  {
    id: "rvn-acc-02",
    name: "Obsidian Signet Ring 0.925",
    slug: "obsidian-signet-ring",
    category: "accessories",
    price: 180,
    description: "Hand-cast oxidized sterling silver featuring a flush-set faceted natural black obsidian gemstone. Brutalist square face with beveled corners.",
    details: "Solid 925 Sterling Silver with rhodium plating. Natural Black Obsidian. Hallmarked in London.",
    images: [
      "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=1200&q=80"
    ],
    sizes: ["US 8", "US 9", "US 10", "US 11"],
    stock: 16,
    featured: false,
    createdAt: "2026-02-18T00:00:00.000Z",
    updatedAt: "2026-02-18T00:00:00.000Z"
  }
];
