import React, { useState } from 'react';
import { X, Shield, Lock, AlertTriangle, CheckCircle, Info, ExternalLink, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { loginWithGoogle, loading, authError, clearAuthError } = useAuth();
  const [internalLoading, setInternalLoading] = useState(false);

  if (!isOpen) return null;

  const currentHostname = typeof window !== 'undefined' ? window.location.hostname : '';

  const handleGoogleLogin = async () => {
    setInternalLoading(true);
    clearAuthError();
    try {
      await loginWithGoogle();
      if (onSuccess) onSuccess();
      onClose();
    } catch (err) {
      // Handled in AuthContext
    } finally {
      setInternalLoading(false);
    }
  };

  const isUnauthorizedDomain = authError && authError.toLowerCase().includes('unauthorized-domain');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div
        className="w-full max-w-md bg-neutral-950 border border-white/20 text-white font-mono shadow-2xl p-6 sm:p-8 relative my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white transition-colors"
          aria-label="Close authentication modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-8">
          <div className="inline-flex p-3 rounded-full bg-white/5 border border-white/10 mb-4">
            <Lock className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-black uppercase tracking-[0.2em] font-mono">
            RAVEN ACCOUNT
          </h2>
          <p className="text-xs text-neutral-400 mt-2 font-sans">
            Sign in to access your personal order archive, saved shipping addresses, and exclusive capsule allocations.
          </p>
        </div>

        {/* Error Alert */}
        {authError && (
          <div className="mb-6 p-4 bg-red-950/70 border border-red-500/60 rounded text-xs space-y-2">
            <div className="flex items-center gap-2 text-red-300 font-bold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>AUTHENTICATION NOTICE</span>
            </div>
            <p className="text-red-200 leading-relaxed font-mono text-[11px]">{authError}</p>
            {isUnauthorizedDomain && (
              <div className="mt-2 p-2 bg-black/40 border border-red-900/60 text-[10px] text-neutral-300 font-mono">
                <p className="font-bold text-white mb-1">CONFIGURATION INSTRUCTION:</p>
                <p>1. Open Firebase Console &gt; Authentication &gt; Settings &gt; Authorized domains</p>
                <p>2. Add current host: <strong className="text-white select-all">{currentHostname}</strong></p>
              </div>
            )}
          </div>
        )}

        {/* Google Sign-In Button */}
        <div className="space-y-4">
          <button
            onClick={handleGoogleLogin}
            disabled={internalLoading || loading}
            className="w-full py-4 px-6 bg-white hover:bg-neutral-200 text-black font-bold uppercase tracking-wider text-xs transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-white/10 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {internalLoading || loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-black" />
                <span>CONNECTING GOOGLE OAUTH...</span>
              </>
            ) : (
              <>
                {/* Official Google G SVG */}
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>CONTINUE WITH GOOGLE</span>
              </>
            )}
          </button>

          {/* Features Checklist */}
          <div className="pt-4 border-t border-white/10 space-y-2 text-[11px] text-neutral-400 font-mono">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-neutral-300 shrink-0" />
              <span>Instant profile creation upon initial sign-in</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-neutral-300 shrink-0" />
              <span>Persistent authenticated browser session</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-neutral-300 shrink-0" />
              <span>End-to-end encrypted Firestore security rules</span>
            </div>
          </div>
        </div>

        {/* Security Footer Notice */}
        <div className="mt-8 pt-4 border-t border-white/5 text-center text-[10px] text-neutral-500 font-mono">
          <p>PROTECTED BY GOOGLE CLOUD IDENTITY & FIREBASE</p>
        </div>
      </div>
    </div>
  );
};
