import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, RefreshCw } from 'lucide-react';
import { Product } from '../types.ts';
import { ProductCard } from './ProductCard.tsx';
import { useStore } from '../context/StoreContext.tsx';

interface ProductGridProps {
  onSelectProduct: (product: Product) => void;
  onOpenAuth: () => void;
}

const CATEGORIES = ['all', 'outerwear', 'tops', 'bottoms', 'accessories', 'footwear'] as const;

export const ProductGrid: React.FC<ProductGridProps> = ({
  onSelectProduct,
  onOpenAuth,
}) => {
  const { products, loadingProducts, refreshProducts } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'name'>('featured');

  const filteredProducts = useMemo(() => {
    return products
      .filter((product) => {
        const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
        const matchesQuery =
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.category.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesQuery;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        if (sortBy === 'name') return a.name.localeCompare(b.name);
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      });
  }, [products, selectedCategory, searchQuery, sortBy]);

  return (
    <section id="collection" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-6 border-b border-white/10 gap-6">
        <div>
          <span className="text-[11px] font-mono tracking-[0.25em] uppercase text-neutral-400">
            CATALOG ARCHIVE // 2026
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold uppercase font-mono tracking-tight text-white mt-1">
            CURRENT PIECES
          </h2>
        </div>

        {/* Search & Sort Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Search bar */}
          <div className="relative min-w-[200px] flex-1 sm:flex-initial">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              placeholder="Search garments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-900 border border-white/10 text-white placeholder-neutral-500 text-xs font-mono pl-9 pr-3 py-2 rounded focus:outline-none focus:border-white transition-colors"
            />
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 bg-neutral-900 border border-white/10 px-3 py-1.5 rounded">
            <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-400" />
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="bg-transparent text-xs font-mono text-white focus:outline-none cursor-pointer"
            >
              <option value="featured" className="bg-neutral-900 text-white">Featured</option>
              <option value="price-asc" className="bg-neutral-900 text-white">Price: Low to High</option>
              <option value="price-desc" className="bg-neutral-900 text-white">Price: High to Low</option>
              <option value="name" className="bg-neutral-900 text-white">Alphabetical</option>
            </select>
          </div>

          <button
            onClick={() => refreshProducts()}
            title="Refresh Catalog"
            className="p-2 bg-neutral-900 border border-white/10 hover:border-white text-neutral-400 hover:text-white rounded transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 font-mono scrollbar-none">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 text-xs tracking-wider uppercase rounded-full transition-all whitespace-nowrap ${
              selectedCategory === cat
                ? 'bg-white text-black font-bold'
                : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800 border border-white/5'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      {loadingProducts ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="animate-pulse bg-neutral-900 aspect-[3/4] border border-white/5" />
          ))}
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="py-24 text-center border border-dashed border-white/10 font-mono">
          <p className="text-neutral-400 text-sm">NO PIECES MATCH YOUR QUERY.</p>
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSearchQuery('');
            }}
            className="mt-4 text-xs text-white underline underline-offset-4 hover:text-neutral-300"
          >
            RESET ALL FILTERS
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelectProduct={onSelectProduct}
              onOpenAuth={onOpenAuth}
            />
          ))}
        </div>
      )}
    </section>
  );
};
