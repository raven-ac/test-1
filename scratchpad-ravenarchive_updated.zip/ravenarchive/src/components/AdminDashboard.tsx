import React, { useState, useEffect } from 'react';
import {
  Shield,
  Package,
  Layers,
  ShoppingBag,
  Users,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  XCircle,
  Clock,
  Truck,
  RotateCw,
  Lock,
  ArrowLeft,
  Loader2,
  UserPlus,
  ShieldCheck,
  Check,
  Tag,
  Wallet
} from 'lucide-react';
import { useAuth, BOOTSTRAP_ADMIN_EMAIL } from '../context/AuthContext.tsx';
import { useStore } from '../context/StoreContext.tsx';
import { Product, Order, OrderStatus, UserProfile, Coupon, CouponType, PaymentSubmission, PaymentStatus } from '../types.ts';
import { formatTaka } from '../utils/format.ts';
import {
  getAllOrders,
  updateOrderStatus,
  createProduct,
  updateProduct,
  deleteProduct,
  getAllCustomers,
  getAdminEmails,
  addAdminEmail,
  removeAdminEmail,
  getAllCoupons,
  saveCoupon,
  setCouponActive,
  deleteCoupon,
  normalizeCode,
  getAllPayments,
  updatePaymentStatus
} from '../services/storeService.ts';

type AdminTab = 'overview' | 'products' | 'inventory' | 'orders' | 'customers' | 'admins' | 'coupons' | 'payments';

interface AdminDashboardProps {
  onBackToShop: () => void;
  onOpenAuth: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBackToShop, onOpenAuth }) => {
  const { currentUser, isAdmin } = useAuth();
  const { products, refreshProducts } = useStore();

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<UserProfile[]>([]);
  const [loadingOrders, setLoadingOrders] = useState<boolean>(true);
  const [loadingCustomers, setLoadingCustomers] = useState<boolean>(true);

  // Admin Management State
  const [adminEmails, setAdminEmails] = useState<{ email: string; addedBy?: string; addedAt: string; notes?: string }[]>([]);
  const [loadingAdminEmails, setLoadingAdminEmails] = useState<boolean>(true);
  const [newAdminEmail, setNewAdminEmail] = useState<string>('');
  const [newAdminNotes, setNewAdminNotes] = useState<string>('');
  const [addingAdmin, setAddingAdmin] = useState<boolean>(false);
  const [adminFeedback, setAdminFeedback] = useState<string | null>(null);

  // New Product Modal Form
  const [showAddProductModal, setShowAddProductModal] = useState<boolean>(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<'outerwear' | 'tops' | 'bottoms' | 'accessories' | 'footwear'>('outerwear');
  const [newProdPrice, setNewProdPrice] = useState<number>(3500);
  const [newProdStock, setNewProdStock] = useState<number>(20);
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdDetails, setNewProdDetails] = useState('');
  const [newProdImage, setNewProdImage] = useState('https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=1200&q=80');
  const [newProdSizes, setNewProdSizes] = useState('S, M, L, XL');
  const [savingProduct, setSavingProduct] = useState(false);

  // Coupons
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [couponCode, setCouponCode] = useState('');
  const [couponType, setCouponType] = useState<CouponType>('percent');
  const [couponValue, setCouponValue] = useState<number>(10);
  const [couponMinOrder, setCouponMinOrder] = useState<number>(0);
  const [couponMaxUses, setCouponMaxUses] = useState<number>(0);
  const [couponExpiry, setCouponExpiry] = useState('');
  const [savingCoupon, setSavingCoupon] = useState(false);
  const [couponFeedback, setCouponFeedback] = useState<string | null>(null);

  // Manual payments submitted via /pay/:id
  const [payments, setPayments] = useState<PaymentSubmission[]>([]);

  const loadCouponsAndPayments = async () => {
    try { setCoupons(await getAllCoupons()); } catch (e) { console.warn('Could not load coupons:', e); }
    try { setPayments(await getAllPayments()); } catch (e) { console.warn('Could not load payments:', e); }
  };

  useEffect(() => {
    if (isAdmin) loadCouponsAndPayments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    setCouponFeedback(null);
    const code = normalizeCode(couponCode);
    if (!code) { setCouponFeedback('কুপন কোড দিন (ইংরেজি অক্ষর/সংখ্যা)'); return; }
    if (couponType === 'percent' && (couponValue < 1 || couponValue > 100)) { setCouponFeedback('শতাংশ ১ থেকে ১০০ এর মধ্যে হতে হবে'); return; }
    if (couponType === 'fixed' && couponValue < 1) { setCouponFeedback('ডিসকাউন্টের পরিমাণ ১ টাকার বেশি হতে হবে'); return; }
    setSavingCoupon(true);
    try {
      const existing = coupons.find(c => c.code === code);
      const now = new Date().toISOString();
      await saveCoupon({
        code,
        type: couponType,
        value: couponValue,
        minOrder: couponMinOrder,
        maxUses: couponMaxUses,
        usedCount: existing?.usedCount ?? 0,
        expiresAt: couponExpiry ? new Date(`${couponExpiry}T23:59:59`).toISOString() : '',
        active: existing?.active ?? true,
        createdAt: existing?.createdAt ?? now,
        updatedAt: now,
      });
      setCouponFeedback(`কুপন ${code} ${existing ? 'আপডেট' : 'তৈরি'} হয়েছে`);
      setCouponCode('');
      setCoupons(await getAllCoupons());
    } catch (err: any) {
      setCouponFeedback('কুপন সেভ করা যায়নি: ' + (err.message || ''));
    } finally {
      setSavingCoupon(false);
    }
  };

  const handleToggleCoupon = async (c: Coupon) => {
    try {
      await setCouponActive(c.code, !c.active);
      setCoupons(prev => prev.map(x => x.code === c.code ? { ...x, active: !c.active } : x));
    } catch (err) { console.error(err); }
  };

  const handleDeleteCoupon = async (code: string) => {
    if (!window.confirm(`কুপন ${code} মুছে ফেলবেন?`)) return;
    try {
      await deleteCoupon(code);
      setCoupons(prev => prev.filter(x => x.code !== code));
    } catch (err) { console.error(err); }
  };

  const handlePaymentStatus = async (p: PaymentSubmission, status: PaymentStatus) => {
    try {
      await updatePaymentStatus(p.id, status);
      setPayments(prev => prev.map(x => x.id === p.id ? { ...x, status } : x));
      if (status === 'verified') {
        const ord = orders.find(o => o.id === p.orderId);
        if (ord && ord.status === 'pending') await handleUpdateStatus(ord.id, 'processing');
      }
    } catch (err) { console.error(err); }
  };

  const fetchAdminEmailsList = async () => {
    setLoadingAdminEmails(true);
    try {
      const records = await getAdminEmails();
      setAdminEmails(records);
    } catch (err) {
      console.warn('Failed to load admin emails:', err);
    } finally {
      setLoadingAdminEmails(false);
    }
  };

  // Load orders, customers, and admin emails if admin
  useEffect(() => {
    if (isAdmin) {
      setLoadingOrders(true);
      getAllOrders()
        .then((items) => setOrders(items))
        .catch((err) => console.warn('Admin: Failed to fetch all orders:', err))
        .finally(() => setLoadingOrders(false));

      setLoadingCustomers(true);
      getAllCustomers()
        .then((users) => setCustomers(users))
        .catch((err) => console.warn('Admin: Failed to fetch customers:', err))
        .finally(() => setLoadingCustomers(false));

      fetchAdminEmailsList();
    }
  }, [isAdmin]);

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminEmail.trim() || !newAdminEmail.includes('@')) {
      setAdminFeedback('Please enter a valid Gmail address.');
      return;
    }
    const targetEmail = newAdminEmail.trim().toLowerCase();
    if (targetEmail === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) {
      setAdminFeedback('This email is already the primary root administrator.');
      return;
    }
    if (adminEmails.some(a => a.email.toLowerCase() === targetEmail)) {
      setAdminFeedback('This email address has already been authorized as an administrator.');
      return;
    }

    setAddingAdmin(true);
    setAdminFeedback(null);
    try {
      await addAdminEmail(targetEmail, currentUser?.email || 'Admin', newAdminNotes);
      setNewAdminEmail('');
      setNewAdminNotes('');
      setAdminFeedback(`Admin access granted to ${targetEmail}. When this user signs in with Google, they will immediately have full administrator privileges.`);
      await fetchAdminEmailsList();
    } catch (err: any) {
      setAdminFeedback('Failed to authorize admin: ' + err.message);
    } finally {
      setAddingAdmin(false);
    }
  };

  const handleRemoveAdmin = async (emailToRemove: string) => {
    if (emailToRemove.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) {
      alert('The primary root administrator cannot be revoked.');
      return;
    }
    if (!confirm(`Are you sure you want to revoke administrator access for ${emailToRemove}?`)) {
      return;
    }
    try {
      await removeAdminEmail(emailToRemove);
      setAdminEmails(prev => prev.filter(a => a.email.toLowerCase() !== emailToRemove.toLowerCase()));
      setAdminFeedback(`Administrator privileges revoked for ${emailToRemove}.`);
    } catch (err: any) {
      alert('Failed to revoke admin: ' + err.message);
    }
  };

  // UNAUTHORIZED SHIELD: Strict security check
  if (!currentUser || !isAdmin) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-24 font-mono text-white text-center">
        <div className="inline-flex p-4 rounded-full bg-red-950/60 border border-red-500/50 mb-6">
          <Lock className="w-8 h-8 text-red-400" />
        </div>
        <span className="text-red-400 text-xs tracking-widest block font-bold mb-2">
          ERROR 403 // FORBIDDEN ACCESS
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight mb-4">
          ADMINISTRATIVE TERMINAL RESTRICTED
        </h2>
        <p className="text-neutral-400 text-xs sm:text-sm font-sans max-w-lg mx-auto mb-8 leading-relaxed">
          {currentUser
            ? `Your current identity (${currentUser.email}) does not possess verified administrator credentials. Firestore security rules strictly prohibit non-admin users from reading or mutating operational records.`
            : 'You are currently not signed in. Cryptographic authorization tokens are required to establish an admin session.'}
        </p>

        <div className="p-4 bg-neutral-950 border border-white/10 text-left text-xs max-w-md mx-auto mb-8 space-y-1 text-neutral-400">
          <p className="font-bold text-white mb-2">SECURITY SPECIFICATION AUDIT:</p>
          <p>• Role spoofing blocked at database rule level.</p>
          <p>• Bootstrapped Admin: a.mdnuhad534@gmail.com</p>
          <p>• Current User: {currentUser ? currentUser.email : 'Anonymous Guest'}</p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={onOpenAuth}
            className="w-full sm:w-auto px-6 py-3 bg-white text-black font-bold uppercase text-xs hover:bg-neutral-200 transition-colors inline-flex items-center justify-center gap-2"
          >
            <Lock className="w-4 h-4" />
            <span>Sign In with Google (Admin)</span>
          </button>
          <button
            onClick={onBackToShop}
            className="w-full sm:w-auto px-6 py-3 border border-white/20 hover:border-white text-white font-bold uppercase text-xs transition-colors inline-flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Storefront</span>
          </button>
        </div>
      </div>
    );
  }

  // Calculate Metrics
  const totalRevenue = orders.reduce((sum, ord) => sum + (ord.status !== 'cancelled' ? ord.total : 0), 0);
  const totalUnitsInStock = products.reduce((sum, p) => sum + p.stock, 0);
  const lowStockCount = products.filter(p => p.stock <= 5).length;

  const handleUpdateStatus = async (orderId: string, nextStatus: OrderStatus) => {
    try {
      await updateOrderStatus(orderId, nextStatus);
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: nextStatus } : o));
    } catch (err: any) {
      alert('Failed to update order status: ' + err.message);
    }
  };

  const handleStockAdjust = async (productId: string, delta: number) => {
    const target = products.find(p => p.id === productId);
    if (!target) return;
    const newStock = Math.max(0, target.stock + delta);
    try {
      await updateProduct(productId, { stock: newStock });
      await refreshProducts();
    } catch (err: any) {
      alert('Failed to update stock: ' + err.message);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product from the live catalog?')) return;
    try {
      await deleteProduct(id);
      await refreshProducts();
    } catch (err: any) {
      alert('Failed to delete product: ' + err.message);
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProduct(true);
    try {
      const slug = newProdName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      const id = `rvn-${newProdCategory.slice(0, 3)}-${Date.now()}`;
      const now = new Date().toISOString();

      const prod: Product = {
        id,
        name: newProdName,
        slug,
        category: newProdCategory,
        price: Number(newProdPrice),
        description: newProdDesc,
        details: newProdDetails || 'Archival piece. High-density textile construction.',
        images: [newProdImage],
        sizes: newProdSizes.split(',').map(s => s.trim()).filter(Boolean),
        stock: Number(newProdStock),
        featured: false,
        createdAt: now,
        updatedAt: now,
      };

      await createProduct(prod);
      await refreshProducts();
      setShowAddProductModal(false);
      // Reset
      setNewProdName('');
      setNewProdDesc('');
    } catch (err: any) {
      alert('Failed to create product: ' + err.message);
    } finally {
      setSavingProduct(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 font-mono text-white">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 mb-8 border-b border-white/10 gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] tracking-widest uppercase text-neutral-400">
              CRYPTOGRAPHIC ADMIN TERMINAL // LIVE
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight">
            RAVEN OPERATIONS
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              refreshProducts();
              getAllOrders().then(setOrders);
              getAllCustomers().then(setCustomers);
              fetchAdminEmailsList();
            }}
            className="px-3 py-2 bg-neutral-900 border border-white/10 hover:border-white text-xs flex items-center gap-1.5 transition-colors"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Sync DB</span>
          </button>
          <button
            onClick={onBackToShop}
            className="px-4 py-2 bg-white text-black text-xs font-bold uppercase hover:bg-neutral-200 transition-colors"
          >
            Storefront
          </button>
        </div>
      </div>

      {/* Admin Tab Navigation */}
      <div className="flex border-b border-white/10 mb-8 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('overview')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'overview' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('products')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'products' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Catalog ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('inventory')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'inventory' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Inventory ({totalUnitsInStock} units)</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'orders' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('customers')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'customers' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Customers</span>
        </button>

        <button
          onClick={() => setActiveTab('admins')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'admins' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Admins ({1 + adminEmails.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('coupons')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'coupons' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <Tag className="w-3.5 h-3.5" />
          <span>Coupons ({coupons.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('payments')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'payments' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <Wallet className="w-3.5 h-3.5" />
          <span>Payments ({payments.filter(p => p.status === 'submitted').length})</span>
        </button>
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Key Metric Tiles */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-neutral-950 border border-white/10">
              <span className="text-[10px] text-neutral-500 uppercase tracking-widest block">
                TOTAL GROSS SALES
              </span>
              <p className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                {formatTaka(totalRevenue)}
              </p>
              <span className="text-[10px] text-neutral-400 mt-2 block">US Dollar</span>
            </div>

            <div className="p-5 bg-neutral-950 border border-white/10">
              <span className="text-[10px] text-neutral-500 uppercase tracking-widest block">
                CONFIRMED ORDERS
              </span>
              <p className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                {orders.length}
              </p>
              <span className="text-[10px] text-neutral-400 mt-2 block">All recorded transactions</span>
            </div>

            <div className="p-5 bg-neutral-950 border border-white/10">
              <span className="text-[10px] text-neutral-500 uppercase tracking-widest block">
                TOTAL CATALOG SKUS
              </span>
              <p className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                {products.length}
              </p>
              <span className="text-[10px] text-neutral-400 mt-2 block">
                {totalUnitsInStock} physical units
              </span>
            </div>

            <div className="p-5 bg-neutral-950 border border-white/10">
              <span className="text-[10px] text-neutral-500 uppercase tracking-widest block">
                LOW STOCK WARNINGS
              </span>
              <p className={`text-2xl sm:text-3xl font-extrabold mt-1 ${lowStockCount > 0 ? 'text-amber-400' : 'text-white'}`}>
                {lowStockCount}
              </p>
              <span className="text-[10px] text-neutral-400 mt-2 block">SKUs under 5 units</span>
            </div>
          </div>

          {/* Recent Orders Overview */}
          <div className="p-6 bg-neutral-950 border border-white/10">
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-white/10">
              <h3 className="text-sm font-bold uppercase tracking-wider">
                RECENT TRANSACTION STREAM
              </h3>
              <button
                onClick={() => setActiveTab('orders')}
                className="text-xs text-neutral-400 hover:text-white underline underline-offset-4"
              >
                View Full Log
              </button>
            </div>

            {orders.length === 0 ? (
              <p className="text-xs text-neutral-500 py-6 text-center">NO ORDERS LOGGED IN FIRESTORE.</p>
            ) : (
              <div className="divide-y divide-white/10 text-xs">
                {orders.slice(0, 5).map((order) => (
                  <div key={order.id} className="py-3 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white mr-3">#{order.id}</span>
                      <span className="text-neutral-400">{order.customerEmail}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-bold">{formatTaka(order.total)}</span>
                      <span className="uppercase text-[10px] px-2 py-0.5 rounded bg-white/10">
                        {order.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PRODUCTS */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-white/10">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider">PRODUCT CATALOG MANAGEMENT</h3>
              <p className="text-xs text-neutral-400 font-sans mt-0.5">
                Add, modify pricing, adjust photography, and archive garment capsules.
              </p>
            </div>
            <button
              onClick={() => setShowAddProductModal(true)}
              className="px-4 py-2 bg-white text-black text-xs font-bold uppercase flex items-center gap-1.5 hover:bg-neutral-200 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Garment</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((p) => (
              <div key={p.id} className="p-4 bg-neutral-950 border border-white/10 flex flex-col justify-between">
                <div>
                  <div className="relative aspect-[3/4] bg-neutral-900 border border-white/10 overflow-hidden mb-3">
                    <img src={p.images[0]} alt="" className="w-full h-full object-cover grayscale contrast-110" />
                    <span className="absolute top-2 left-2 text-[9px] bg-black/80 px-2 py-0.5 text-neutral-300 font-bold uppercase">
                      {p.category}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-white line-clamp-1">{p.name}</h4>
                  <p className="text-xs text-neutral-400 mt-1">ID: {p.id}</p>
                  <p className="text-xs font-bold text-white mt-1">{formatTaka(p.price)}</p>
                  <p className="text-xs text-neutral-400">Stock: {p.stock} units</p>
                </div>

                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleStockAdjust(p.id, 5)}
                      className="px-2 py-1 bg-neutral-900 border border-white/20 text-neutral-300 hover:text-white"
                      title="Add 5 units stock"
                    >
                      +5 Stock
                    </button>
                    <button
                      onClick={() => handleStockAdjust(p.id, -5)}
                      className="px-2 py-1 bg-neutral-900 border border-white/20 text-neutral-300 hover:text-white"
                      title="Subtract 5 units stock"
                    >
                      -5 Stock
                    </button>
                  </div>
                  <button
                    onClick={() => handleDeleteProduct(p.id)}
                    className="p-1 text-red-400 hover:text-red-300"
                    title="Delete product"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: INVENTORY */}
      {activeTab === 'inventory' && (
        <div className="space-y-6">
          <div className="pb-4 border-b border-white/10">
            <h3 className="text-sm font-bold uppercase tracking-wider">STOCK & WAREHOUSE ALLOCATIONS</h3>
            <p className="text-xs text-neutral-400 font-sans mt-0.5">
              Live inventory counts across all active SKU sizing matrixes.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-white/10">
              <thead className="bg-neutral-900 border-b border-white/10 text-neutral-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3">SKU ID</th>
                  <th className="p-3">Garment Name</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Unit Price</th>
                  <th className="p-3">Current Stock</th>
                  <th className="p-3 text-right">Quick Stock Delta</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-neutral-900/40">
                    <td className="p-3 font-mono text-neutral-400">{p.id}</td>
                    <td className="p-3 font-bold text-white">{p.name}</td>
                    <td className="p-3 uppercase text-neutral-400">{p.category}</td>
                    <td className="p-3 font-bold">{formatTaka(p.price)}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        p.stock <= 5 ? 'bg-amber-950 text-amber-300 border border-amber-500' : 'bg-neutral-800 text-neutral-200'
                      }`}>
                        {p.stock} units
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={() => handleStockAdjust(p.id, -1)}
                        className="px-2 py-0.5 bg-neutral-900 border border-white/20 hover:border-white"
                      >
                        -1
                      </button>
                      <button
                        onClick={() => handleStockAdjust(p.id, 1)}
                        className="px-2 py-0.5 bg-neutral-900 border border-white/20 hover:border-white"
                      >
                        +1
                      </button>
                      <button
                        onClick={() => handleStockAdjust(p.id, 10)}
                        className="px-2 py-0.5 bg-neutral-900 border border-white/20 hover:border-white"
                      >
                        +10
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: ORDERS */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="pb-4 border-b border-white/10">
            <h3 className="text-sm font-bold uppercase tracking-wider">ALL ORDERS MANAGEMENT</h3>
            <p className="text-xs text-neutral-400 font-sans mt-0.5">
              Review customer orders, update tracking status, and monitor courier fulfillment.
            </p>
          </div>

          {loadingOrders ? (
            <div className="py-16 text-center text-neutral-400">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
              <span>Querying orders from Cloud Firestore...</span>
            </div>
          ) : orders.length === 0 ? (
            <div className="p-12 text-center bg-neutral-950 border border-white/10 text-neutral-400">
              NO TRANSACTION ORDERS RECORDED YET.
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((ord) => (
                <div key={ord.id} className="p-6 bg-neutral-950 border border-white/10 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-white/10 gap-2">
                    <div>
                      <span className="font-bold text-white text-sm">ORDER #{ord.id}</span>
                      <p className="text-xs text-neutral-400 mt-0.5">
                        Customer: <strong className="text-white">{ord.customerName}</strong> ({ord.customerEmail})
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold">{formatTaka(ord.total)}</span>
                      <select
                        value={ord.status}
                        onChange={(e) => handleUpdateStatus(ord.id, e.target.value as OrderStatus)}
                        className="bg-neutral-900 border border-white/20 text-xs px-2.5 py-1 text-white uppercase focus:outline-none"
                      >
                        <option value="pending">Pending</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </div>
                  </div>

                  {/* Items */}
                  <div className="space-y-1.5 text-xs text-neutral-300">
                    {ord.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between">
                        <span>{item.quantity}× {item.name} ({item.size})</span>
                        <span>{formatTaka(item.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Address */}
                  <div className="text-[11px] text-neutral-400 pt-2 border-t border-white/5">
                    <span className="font-bold text-neutral-500 block mb-0.5">DESTINATION:</span>
                    <span>{ord.shippingAddress}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: CUSTOMERS */}
      {activeTab === 'customers' && (
        <div className="space-y-6">
          <div className="pb-4 border-b border-white/10">
            <h3 className="text-sm font-bold uppercase tracking-wider">REGISTERED CUSTOMER ACCOUNTS</h3>
            <p className="text-xs text-neutral-400 font-sans mt-0.5">
              Profiles generated upon Google OAuth authentication into Cloud Firestore.
            </p>
          </div>

          {loadingCustomers ? (
            <div className="py-16 text-center text-neutral-400">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
              <span>Fetching customers...</span>
            </div>
          ) : customers.length === 0 ? (
            <div className="p-8 text-center bg-neutral-950 border border-white/10 text-neutral-400">
              NO CUSTOMERS RECORDED IN /users COLLECTION YET.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-white/10 font-mono">
                <thead className="bg-neutral-900 border-b border-white/10 text-neutral-400 uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Customer</th>
                    <th className="p-3">Email Address</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">Joined Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {customers.map((c) => (
                    <tr key={c.id} className="hover:bg-neutral-900/40">
                      <td className="p-3 font-bold text-white flex items-center gap-2">
                        <img
                          src={c.photoURL || `https://api.dicebear.com/7.x/shapes/svg?seed=${c.id}`}
                          alt=""
                          className="w-6 h-6 rounded-full border border-white/20"
                        />
                        <span>{c.displayName || 'Member'}</span>
                      </td>
                      <td className="p-3 text-neutral-300">{c.email}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 uppercase text-[9px] font-bold rounded ${
                          c.role === 'admin' ? 'bg-white text-black' : 'bg-neutral-800 text-neutral-300'
                        }`}>
                          {c.role}
                        </span>
                      </td>
                      <td className="p-3 text-neutral-400">
                        {c.createdAt ? new Date(c.createdAt).toLocaleDateString() : 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 7: COUPONS */}
      {activeTab === 'coupons' && (
        <div className="space-y-8">
          <div className="pb-4 border-b border-white/10">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">COUPON CODES</h3>
            <p className="text-xs text-neutral-400 font-sans mt-0.5 max-w-2xl">
              কুপন তৈরি করুন — গ্রাহক কার্টে কোডটি দিলে ডিসকাউন্ট পাবেন। একই কোড আবার সেভ করলে সেটি আপডেট হবে।
            </p>
          </div>

          <form onSubmit={handleCreateCoupon} className="p-6 bg-neutral-950 border border-white/20 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-[10px] text-neutral-400 mb-1">COUPON CODE *</label>
              <input
                type="text"
                required
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                placeholder="EID20"
                className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white uppercase focus:outline-none focus:border-white"
              />
            </div>
            <div>
              <label className="block text-[10px] text-neutral-400 mb-1">DISCOUNT TYPE</label>
              <select
                value={couponType}
                onChange={(e) => setCouponType(e.target.value as CouponType)}
                className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
              >
                <option value="percent">শতাংশ (%)</option>
                <option value="fixed">নির্দিষ্ট টাকা (৳)</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] text-neutral-400 mb-1">
                {couponType === 'percent' ? 'DISCOUNT (%) *' : 'DISCOUNT AMOUNT (৳) *'}
              </label>
              <input
                type="number"
                required
                min={1}
                max={couponType === 'percent' ? 100 : undefined}
                value={couponValue}
                onChange={(e) => setCouponValue(Number(e.target.value))}
                className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
              />
            </div>
            <div>
              <label className="block text-[10px] text-neutral-400 mb-1">MINIMUM ORDER (৳) — 0 = নেই</label>
              <input
                type="number"
                min={0}
                value={couponMinOrder}
                onChange={(e) => setCouponMinOrder(Number(e.target.value))}
                className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
              />
            </div>
            <div>
              <label className="block text-[10px] text-neutral-400 mb-1">MAX USES — 0 = সীমাহীন</label>
              <input
                type="number"
                min={0}
                value={couponMaxUses}
                onChange={(e) => setCouponMaxUses(Number(e.target.value))}
                className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
              />
            </div>
            <div>
              <label className="block text-[10px] text-neutral-400 mb-1">EXPIRY DATE — খালি = মেয়াদ নেই</label>
              <input
                type="date"
                value={couponExpiry}
                onChange={(e) => setCouponExpiry(e.target.value)}
                className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
              />
            </div>
            <div className="sm:col-span-2 flex items-center gap-4">
              <button
                type="submit"
                disabled={savingCoupon}
                className="px-5 py-2.5 bg-white text-black font-bold uppercase text-xs hover:bg-neutral-200 disabled:bg-neutral-800 disabled:text-neutral-500 flex items-center gap-2"
              >
                {savingCoupon ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                <span>Save Coupon</span>
              </button>
              {couponFeedback && <span className="text-neutral-300">{couponFeedback}</span>}
            </div>
          </form>

          {coupons.length === 0 ? (
            <div className="p-12 text-center bg-neutral-950 border border-white/10 text-neutral-400 text-xs">
              এখনো কোনো কুপন নেই।
            </div>
          ) : (
            <div className="overflow-x-auto border border-white/10">
              <table className="w-full text-xs text-left">
                <thead className="bg-neutral-900 text-neutral-400 uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Code</th>
                    <th className="p-3">Discount</th>
                    <th className="p-3">Min order</th>
                    <th className="p-3">Used</th>
                    <th className="p-3">Expires</th>
                    <th className="p-3">Status</th>
                    <th className="p-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10 bg-neutral-950">
                  {coupons.map((c) => {
                    const expired = c.expiresAt && new Date(c.expiresAt).getTime() < Date.now();
                    return (
                      <tr key={c.code}>
                        <td className="p-3 font-bold text-white">{c.code}</td>
                        <td className="p-3">{c.type === 'percent' ? `${c.value}%` : formatTaka(c.value)}</td>
                        <td className="p-3">{c.minOrder > 0 ? formatTaka(c.minOrder) : '—'}</td>
                        <td className="p-3">{c.usedCount}{c.maxUses > 0 ? ` / ${c.maxUses}` : ''}</td>
                        <td className="p-3">{c.expiresAt ? new Date(c.expiresAt).toLocaleDateString('bn-BD') : '—'}</td>
                        <td className="p-3">
                          <button
                            onClick={() => handleToggleCoupon(c)}
                            className={`px-2 py-0.5 text-[10px] uppercase font-bold ${
                              expired ? 'bg-red-900/50 text-red-300' : c.active ? 'bg-emerald-900/50 text-emerald-300' : 'bg-white/10 text-neutral-400'
                            }`}
                          >
                            {expired ? 'Expired' : c.active ? 'Active' : 'Disabled'}
                          </button>
                        </td>
                        <td className="p-3 text-right">
                          <button onClick={() => handleDeleteCoupon(c.code)} className="p-1 text-neutral-500 hover:text-red-400" aria-label="Delete coupon">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 8: MANUAL PAYMENTS (bKash via /pay/:id) */}
      {activeTab === 'payments' && (
        <div className="space-y-6">
          <div className="pb-4 border-b border-white/10">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">MANUAL PAYMENTS</h3>
            <p className="text-xs text-neutral-400 font-sans mt-0.5 max-w-2xl">
              গ্রাহক /pay/অর্ডার-আইডি পেজে যে TrxID জমা দিয়েছেন সেগুলো এখানে দেখুন। bKash অ্যাপে TrxID মিলিয়ে Verify করুন — Verify করলে অর্ডার Processing হবে।
            </p>
          </div>

          {payments.length === 0 ? (
            <div className="p-12 text-center bg-neutral-950 border border-white/10 text-neutral-400 text-xs">
              এখনো কোনো পেমেন্ট জমা পড়েনি।
            </div>
          ) : (
            <div className="overflow-x-auto border border-white/10">
              <table className="w-full text-xs text-left">
                <thead className="bg-neutral-900 text-neutral-400 uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Order</th>
                    <th className="p-3">Sender</th>
                    <th className="p-3">TrxID</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Order total</th>
                    <th className="p-3">Status</th>
                    <th className="p-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10 bg-neutral-950">
                  {payments.map((p) => {
                    const ord = orders.find(o => o.id === p.orderId);
                    const dup = payments.filter(x => x.trxid === p.trxid).length > 1;
                    return (
                      <tr key={p.id}>
                        <td className="p-3 font-bold text-white">#{p.orderId}</td>
                        <td className="p-3">{p.sender}</td>
                        <td className="p-3 font-mono">
                          {p.trxid}
                          {dup && <span className="ml-2 text-[9px] px-1.5 py-0.5 bg-red-900/60 text-red-300">DUPLICATE</span>}
                        </td>
                        <td className="p-3">{p.amount > 0 ? formatTaka(p.amount) : '—'}</td>
                        <td className="p-3">{ord ? formatTaka(ord.total) : 'অর্ডার পাওয়া যায়নি'}</td>
                        <td className="p-3 uppercase text-[10px] font-bold">{p.status}</td>
                        <td className="p-3 text-right whitespace-nowrap">
                          {p.status === 'submitted' && (
                            <>
                              <button onClick={() => handlePaymentStatus(p, 'verified')} className="px-2 py-1 bg-emerald-600 text-white font-bold text-[10px] uppercase mr-2">Verify</button>
                              <button onClick={() => handlePaymentStatus(p, 'rejected')} className="px-2 py-1 bg-neutral-800 text-white text-[10px] uppercase">Reject</button>
                            </>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: ADMINISTRATORS MANAGEMENT */}
      {activeTab === 'admins' && (
        <div className="space-y-8">
          <div className="pb-4 border-b border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-[10px] text-neutral-400 uppercase tracking-widest">
                ROLE-BASED ACCESS CONTROL (RBAC)
              </span>
            </div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              ADMINISTRATIVE IDENTITY DISPATCH
            </h3>
            <p className="text-xs text-neutral-400 font-sans mt-0.5 max-w-2xl">
              Add any trusted Gmail address below. When the designated individual signs in using Google OAuth with that Gmail, they will automatically gain full administrative privileges to manage products, inventory, orders, and customer records.
            </p>
          </div>

          {/* Feedback Banner */}
          {adminFeedback && (
            <div className="p-4 bg-neutral-900 border border-white/20 text-xs flex items-start gap-3">
              <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div className="flex-1 text-neutral-200">
                <p className="font-bold text-white mb-0.5">ADMIN REGISTRY UPDATE</p>
                <p>{adminFeedback}</p>
              </div>
              <button
                onClick={() => setAdminFeedback(null)}
                className="text-neutral-500 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          {/* Add Admin Form */}
          <div className="p-6 bg-neutral-950 border border-white/20 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-neutral-300" />
              <span>AUTHORIZE NEW ADMINISTRATOR</span>
            </h4>

            <form onSubmit={handleAddAdmin} className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="md:col-span-1">
                <label className="block text-[10px] text-neutral-400 uppercase mb-1">
                  GMAIL ADDRESS *
                </label>
                <input
                  type="email"
                  required
                  placeholder="e.g. partner@gmail.com"
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white placeholder-neutral-500 focus:outline-none focus:border-white"
                />
              </div>

              <div className="md:col-span-1">
                <label className="block text-[10px] text-neutral-400 uppercase mb-1">
                  ROLE TITLE / NOTE (OPTIONAL)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Operations Co-Lead"
                  value={newAdminNotes}
                  onChange={(e) => setNewAdminNotes(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white placeholder-neutral-500 focus:outline-none focus:border-white"
                />
              </div>

              <div className="md:col-span-1 flex items-end">
                <button
                  type="submit"
                  disabled={addingAdmin}
                  className="w-full py-2.5 px-4 bg-white text-black font-bold uppercase tracking-wider text-xs hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {addingAdmin ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>AUTHORIZING...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>AUTHORIZE ADMIN</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Current Administrators Table */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              CURRENT AUTHORIZED ADMINISTRATORS ({1 + adminEmails.length})
            </h4>

            <div className="overflow-x-auto border border-white/10 bg-neutral-950">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-neutral-900 border-b border-white/10 text-neutral-400 uppercase text-[10px]">
                  <tr>
                    <th className="p-3.5">Administrator Email</th>
                    <th className="p-3.5">Role / Designation</th>
                    <th className="p-3.5">Authorized Date</th>
                    <th className="p-3.5">Authorized By</th>
                    <th className="p-3.5 text-right">Access Control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {/* Primary Bootstrapped Admin */}
                  <tr className="bg-white/5">
                    <td className="p-3.5 font-bold text-white flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      <span>{BOOTSTRAP_ADMIN_EMAIL}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500 font-bold text-[9px] uppercase">
                        ROOT OWNER
                      </span>
                    </td>
                    <td className="p-3.5 text-neutral-400">Project Genesis</td>
                    <td className="p-3.5 text-neutral-400">System Kernel</td>
                    <td className="p-3.5 text-right text-neutral-500">
                      <span className="text-[10px] uppercase font-bold flex items-center justify-end gap-1">
                        <Lock className="w-3 h-3" /> Immutable
                      </span>
                    </td>
                  </tr>

                  {/* Added Admins */}
                  {adminEmails.map((item) => (
                    <tr key={item.email} className="hover:bg-neutral-900/50 transition-colors">
                      <td className="p-3.5 font-bold text-white flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-blue-400" />
                        <span>{item.email}</span>
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-500 font-bold text-[9px] uppercase">
                          {item.notes || 'Co-Administrator'}
                        </span>
                      </td>
                      <td className="p-3.5 text-neutral-400">
                        {item.addedAt ? new Date(item.addedAt).toLocaleDateString() : 'Active'}
                      </td>
                      <td className="p-3.5 text-neutral-400 truncate max-w-[120px]">
                        {item.addedBy || 'Administrator'}
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => handleRemoveAdmin(item.email)}
                          className="px-2.5 py-1 text-red-400 hover:text-red-300 border border-red-900/60 hover:border-red-700 bg-red-950/30 text-[10px] uppercase font-bold transition-colors"
                        >
                          Revoke Access
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add New Product */}
      {showAddProductModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div
            className="w-full max-w-lg bg-neutral-950 border border-white/20 p-6 sm:p-8 font-mono text-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-base font-bold uppercase tracking-wider mb-4 pb-2 border-b border-white/10">
              CREATE NEW ARCHIVAL PIECE
            </h3>

            <form onSubmit={handleCreateProduct} className="space-y-4 text-xs">
              <div>
                <label className="block text-[10px] text-neutral-400 mb-1">GARMENT NAME *</label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">CATEGORY *</label>
                  <select
                    value={newProdCategory}
                    onChange={(e: any) => setNewProdCategory(e.target.value)}
                    className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white uppercase"
                  >
                    <option value="outerwear">Outerwear</option>
                    <option value="tops">Tops</option>
                    <option value="bottoms">Bottoms</option>
                    <option value="accessories">Accessories</option>
                    <option value="footwear">Footwear</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">RETAIL PRICE (৳ BDT) *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">INITIAL STOCK *</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">SIZES (COMMA SEPARATED)</label>
                  <input
                    type="text"
                    value={newProdSizes}
                    onChange={(e) => setNewProdSizes(e.target.value)}
                    className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-neutral-400 mb-1">IMAGE URL</label>
                <input
                  type="url"
                  required
                  value={newProdImage}
                  onChange={(e) => setNewProdImage(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                />
              </div>

              <div>
                <label className="block text-[10px] text-neutral-400 mb-1">CONCEPT DESCRIPTION</label>
                <textarea
                  rows={3}
                  value={newProdDesc}
                  onChange={(e) => setNewProdDesc(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowAddProductModal(false)}
                  className="px-4 py-2 border border-white/20 text-neutral-400 hover:text-white text-xs uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingProduct}
                  className="px-6 py-2 bg-white text-black font-bold text-xs uppercase hover:bg-neutral-200 disabled:opacity-50"
                >
                  {savingProduct ? 'Creating...' : 'Publish Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
