import React, { useState } from 'react';
import { X, Heart, ShoppingBag, ShieldCheck, Truck, RotateCcw, Check } from 'lucide-react';
import { Product } from '../types.ts';
import { useStore } from '../context/StoreContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { formatTaka } from '../utils/format.ts';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onOpenAuth: () => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onOpenAuth,
}) => {
  if (!product) return null;

  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const { currentUser } = useAuth();
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);
  const [added, setAdded] = useState<boolean>(false);

  const saved = isWishlisted(product.id);

  const handleAdd = () => {
    if (product.stock <= 0) return;
    addToCart(product, selectedSize, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleWishlist = () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    toggleWishlist(product.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div
        className="relative w-full max-w-4xl bg-neutral-950 border border-white/20 text-white rounded-none shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 bg-black/60 hover:bg-white hover:text-black rounded-full border border-white/20 transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Gallery View */}
          <div className="relative bg-neutral-900 flex flex-col">
            <div className="relative aspect-[3/4] overflow-hidden">
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover grayscale contrast-110"
              />
            </div>
            {/* Gallery Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-2 p-3 bg-neutral-950 border-t border-white/10 overflow-x-auto">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`w-14 h-16 border overflow-hidden transition-all ${
                      activeImageIndex === idx ? 'border-white' : 'border-white/20 opacity-60'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover grayscale" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details & Purchasing */}
          <div className="p-6 sm:p-8 flex flex-col justify-between font-mono bg-neutral-950">
            <div>
              <div className="flex items-center justify-between text-[11px] text-neutral-400 uppercase tracking-widest mb-2">
                <span>{product.category}</span>
                <span className="font-bold text-white">SKU: {product.id}</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight text-white mb-3">
                {product.name}
              </h2>

              <p className="text-xl font-bold text-white mb-6">
                {formatTaka(product.price)}
              </p>

              {/* Description */}
              <div className="mb-6 space-y-3 font-sans text-xs sm:text-sm text-neutral-300 leading-relaxed">
                <p>{product.description}</p>
                <div className="p-3 bg-neutral-900 border border-white/10 font-mono text-[11px] text-neutral-400">
                  <p className="font-bold text-neutral-200 mb-1">SPECIFICATIONS & CARE:</p>
                  <p>{product.details}</p>
                </div>
              </div>

              {/* Sizes Selection */}
              <div className="mb-6 font-mono">
                <div className="flex items-center justify-between mb-2 text-xs">
                  <span className="text-neutral-400">SELECT FIT / SIZE</span>
                  <span className="text-neutral-500 underline cursor-pointer hover:text-white">SIZE GUIDE</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-3 py-2 text-xs font-bold border transition-colors ${
                        selectedSize === size
                          ? 'border-white bg-white text-black'
                          : 'border-white/20 bg-neutral-900 text-neutral-300 hover:border-white'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions & Inventory */}
            <div className="space-y-4 pt-4 border-t border-white/10 font-mono">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleAdd}
                  disabled={product.stock <= 0}
                  className={`flex-1 py-4 text-xs font-bold uppercase tracking-[0.15em] transition-all flex items-center justify-center gap-2 ${
                    product.stock <= 0
                      ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                      : added
                      ? 'bg-emerald-500 text-black'
                      : 'bg-white text-black hover:bg-neutral-200'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>ADDED TO BAG</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>ALLOCATE TO BAG ({formatTaka(product.price)})</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleWishlist}
                  className={`p-4 border transition-colors ${
                    saved
                      ? 'border-white bg-white text-black'
                      : 'border-white/20 bg-neutral-900 hover:border-white text-white'
                  }`}
                  title={saved ? 'Remove from wishlist' : 'Save to wishlist'}
                >
                  <Heart className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Trust Badges */}
              <div className="grid grid-cols-3 gap-2 text-[10px] text-neutral-400 font-mono pt-3 border-t border-white/5">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-neutral-300" />
                  <span>Authenticated</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-neutral-300" />
                  <span>Express Courier</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-neutral-300" />
                  <span>14-Day Returns</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
