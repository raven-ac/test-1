import { writeBatch, doc } from 'firebase/firestore';
import { db } from '../firebase/config.ts';
import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, ShieldCheck, Truck, CreditCard, Loader2 } from 'lucide-react';
import { useStore } from '../context/StoreContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { UserAddress, Order } from '../types.ts';
import { getUserAddresses, saveUserAddress, createOrder, validateCoupon, couponDiscount, couponUsageUpdate } from '../services/storeService.ts';
import { formatTaka, calcTotals } from '../utils/format.ts';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (orderId: string, total: number) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  onOrderSuccess,
}) => {
  const { cart, cartSubtotal, clearCart, products, appliedCoupon, setAppliedCoupon } = useStore();
  const { currentUser, userProfile } = useAuth();

  const [savedAddresses, setSavedAddresses] = useState<UserAddress[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<string>('new');
  const [loadingAddresses, setLoadingAddresses] = useState<boolean>(true);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [saveToAccount, setSaveToAccount] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [recipientName, setRecipientName] = useState('');
  const [street, setStreet] = useState('');
  const [apartment, setApartment] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('বাংলাদেশ');

  useEffect(() => {
    if (currentUser && isOpen) {
      setRecipientName(userProfile?.displayName || currentUser.displayName || '');
      setLoadingAddresses(true);
      getUserAddresses(currentUser.uid)
        .then((addresses) => {
          setSavedAddresses(addresses);
          const defaultAddr = addresses.find(a => a.isDefault) || addresses[0];
          if (defaultAddr) {
            setSelectedAddressId(defaultAddr.id);
          } else {
            setSelectedAddressId('new');
          }
        })
        .catch((err) => {
          console.warn('Failed to load saved addresses:', err);
          setSelectedAddressId('new');
        })
        .finally(() => setLoadingAddresses(false));
    }
  }, [currentUser, isOpen, userProfile]);

  if (!isOpen || !currentUser) return null;

  const { discount, shipping, tax, total: grandTotal } = calcTotals(
    cartSubtotal,
    couponDiscount(appliedCoupon, cartSubtotal)
  );

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      let finalAddressString = '';

      if (selectedAddressId !== 'new') {
        const found = savedAddresses.find(a => a.id === selectedAddressId);
        if (found) {
          finalAddressString = `${found.recipientName}, ${found.street}${found.apartment ? ' ' + found.apartment : ''}, ${found.city}, ${found.state || ''} ${found.postalCode}, ${found.country}`;
        }
      } else {
        if (!recipientName || !street || !city || !postalCode || !country) {
          throw new Error('Please fill in all required shipping address fields.');
        }
        finalAddressString = `${recipientName}, ${street}${apartment ? ' ' + apartment : ''}, ${city}, ${state || ''} ${postalCode}, ${country}`;

        if (saveToAccount) {
          const newAddr: UserAddress = {
            id: `addr-${Date.now()}`,
            userId: currentUser.uid,
            recipientName,
            street,
            apartment,
            city,
            state,
            postalCode,
            country,
            isDefault: savedAddresses.length === 0,
            createdAt: new Date().toISOString(),
          };
          await saveUserAddress(currentUser.uid, newAddr);
        }
      }

      // Re-validate the coupon right before the order is placed (expiry / usage limit may have changed)
      let finalCoupon = appliedCoupon;
      if (finalCoupon) {
        try {
          finalCoupon = await validateCoupon(finalCoupon.code, cartSubtotal);
        } catch (couponErr: any) {
          setAppliedCoupon(null);
          throw new Error(`কুপন বাতিল হয়েছে: ${couponErr.message}। মোট দাম আবার দেখে অর্ডার করুন।`);
        }
      }
      const finalDiscount = couponDiscount(finalCoupon, cartSubtotal);
      const finalTotals = calcTotals(cartSubtotal, finalDiscount);

      const orderId = `ord-${Date.now()}`;
      const now = new Date().toISOString();

      const newOrder: Order = {
        id: orderId,
        userId: currentUser.uid,
        customerEmail: currentUser.email || 'customer@raven.internal',
        customerName: recipientName || currentUser.displayName || 'RAVEN Member',
        items: cart.map(item => ({
          productId: item.productId,
          name: item.name,
          price: item.price,
          size: item.size,
          quantity: item.quantity,
          image: item.image,
        })),
        subtotal: Number(cartSubtotal.toFixed(2)),
        shipping: Number(finalTotals.shipping.toFixed(2)),
        tax: Number(finalTotals.tax.toFixed(2)),
        total: Number(finalTotals.total.toFixed(2)),
        ...(finalCoupon
          ? { discount: Number(finalTotals.discount.toFixed(2)), couponCode: finalCoupon.code }
          : {}),
        status: 'pending',
        shippingAddress: finalAddressString,
        createdAt: now,
        updatedAt: now,
      };

      await createOrder(newOrder);
      // Product Stock Decrement
      const batch = writeBatch(db);
      for (const item of cart) {
        const productRef = doc(db, 'products', item.productId);
        const targetProduct = products.find(p => p.id === item.productId);
        if (targetProduct) {
          const updatedStock = Math.max(0, targetProduct.stock - item.quantity);
          batch.update(productRef, { stock: updatedStock, updatedAt: now });
        }
      }
      if (finalCoupon) {
        batch.update(doc(db, 'coupons', finalCoupon.code), couponUsageUpdate());
      }
      await batch.commit(); 
      clearCart();
      onOrderSuccess(orderId, newOrder.total);
    } catch (err: any) {
      console.error('Order creation failed:', err);
      setError(err.message || 'Failed to place order. Please review information.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div
        className="w-full max-w-2xl bg-neutral-950 border border-white/20 text-white font-mono shadow-2xl p-6 sm:p-8 relative my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-white/10">
          <div>
            <span className="text-[10px] text-neutral-400 uppercase tracking-widest">
              SECURE FIRESTORE CHECKOUT
            </span>
            <h2 className="text-xl sm:text-2xl font-extrabold uppercase tracking-tight text-white mt-0.5">
              CONFIRM ALLOCATION
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-950/60 border border-red-500/50 text-red-300 text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handlePlaceOrder} className="mt-6 space-y-6">
          {/* Saved Addresses Section */}
          <div>
            <h3 className="text-xs uppercase tracking-wider text-neutral-400 mb-3 flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-white" />
              <span>1. DELIVERY DESTINATION</span>
            </h3>

            {savedAddresses.length > 0 && (
              <div className="space-y-2 mb-4">
                {savedAddresses.map((addr) => (
                  <label
                    key={addr.id}
                    className={`block p-3 border cursor-pointer transition-all ${
                      selectedAddressId === addr.id
                        ? 'border-white bg-white/5'
                        : 'border-white/10 hover:border-white/20 bg-neutral-900'
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      <input
                        type="radio"
                        name="addressSelection"
                        checked={selectedAddressId === addr.id}
                        onChange={() => setSelectedAddressId(addr.id)}
                        className="mt-1 accent-white"
                      />
                      <div className="text-xs">
                        <span className="font-bold text-white">{addr.recipientName}</span>
                        {addr.isDefault && (
                          <span className="ml-2 text-[9px] px-1.5 py-0.5 bg-white text-black font-bold">
                            DEFAULT
                          </span>
                        )}
                        <p className="text-neutral-400 mt-0.5">
                          {addr.street} {addr.apartment || ''}, {addr.city}, {addr.state || ''} {addr.postalCode}, {addr.country}
                        </p>
                      </div>
                    </div>
                  </label>
                ))}

                <label
                  className={`block p-3 border cursor-pointer transition-all ${
                    selectedAddressId === 'new'
                      ? 'border-white bg-white/5'
                      : 'border-white/10 hover:border-white/20 bg-neutral-900'
                  }`}
                >
                  <div className="flex items-center gap-2 text-xs">
                    <input
                      type="radio"
                      name="addressSelection"
                      checked={selectedAddressId === 'new'}
                      onChange={() => setSelectedAddressId('new')}
                      className="accent-white"
                    />
                    <span className="font-bold text-white">+ ENTER A NEW SHIPPING ADDRESS</span>
                  </div>
                </label>
              </div>
            )}

            {/* New Address Fields */}
            {selectedAddressId === 'new' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 bg-neutral-900/60 border border-white/10 text-xs">
                <div className="sm:col-span-2">
                  <label className="block text-[10px] text-neutral-400 mb-1">RECIPIENT FULL NAME *</label>
                  <input
                    type="text"
                    required
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full bg-neutral-950 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[10px] text-neutral-400 mb-1">STREET ADDRESS *</label>
                  <input
                    type="text"
                    required
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    className="w-full bg-neutral-950 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">SUITE / APARTMENT</label>
                  <input
                    type="text"
                    value={apartment}
                    onChange={(e) => setApartment(e.target.value)}
                    className="w-full bg-neutral-950 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">CITY *</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-neutral-950 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">STATE / REGION</label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full bg-neutral-950 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">POSTAL / ZIP CODE *</label>
                  <input
                    type="text"
                    required
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="w-full bg-neutral-950 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[10px] text-neutral-400 mb-1">COUNTRY *</label>
                  <input
                    type="text"
                    required
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full bg-neutral-950 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
                  />
                </div>

                <div className="sm:col-span-2 pt-1 flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="saveAddr"
                    checked={saveToAccount}
                    onChange={(e) => setSaveToAccount(e.target.checked)}
                    className="accent-white"
                  />
                  <label htmlFor="saveAddr" className="text-[11px] text-neutral-300 cursor-pointer">
                    Save address to my customer profile for expedited checkout
                  </label>
                </div>
              </div>
            )}
          </div>

          {/* Payment Simulation Section */}
          <div>
            <h3 className="text-xs uppercase tracking-wider text-neutral-400 mb-2 flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-white" />
              <span>2. PAYMENT METHOD</span>
            </h3>
            <div className="p-3 bg-neutral-900 border border-white/10 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <span className="text-white font-bold">RAVEN EXPRESS VAULT (SIMULATED)</span>
              </div>
              <span className="text-[10px] text-neutral-400">NO CHARGE IN DEMO MODE</span>
            </div>
          </div>

          {/* Order Summary */}
          <div className="p-4 bg-neutral-900 border border-white/10 text-xs space-y-2">
            <div className="flex justify-between text-neutral-400">
              <span>ITEMS ({cart.reduce((s, i) => s + i.quantity, 0)})</span>
              <span>{formatTaka(cartSubtotal)}</span>
            </div>
            {discount > 0 && appliedCoupon && (
              <div className="flex justify-between text-emerald-400">
                <span>ডিসকাউন্ট ({appliedCoupon.code})</span>
                <span>-{formatTaka(discount)}</span>
              </div>
            )}
            <div className="flex justify-between text-neutral-400">
              <span>EXPRESS COURIER</span>
              <span>{shipping === 0 ? 'ফ্রি' : formatTaka(shipping)}</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>ESTIMATED TAX (8%)</span>
              <span>{formatTaka(tax)}</span>
            </div>
            <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-white/10">
              <span>TOTAL PAYABLE</span>
              <span>{formatTaka(grandTotal)}</span>
            </div>
          </div>

          {/* Submit Action */}
          <button
            type="submit"
            disabled={submitting}
            className="w-full py-4 bg-white text-black font-bold uppercase tracking-[0.2em] text-xs hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2 disabled:bg-neutral-800 disabled:text-neutral-500"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>CONFIRMING TRANSACTION IN FIRESTORE...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>AUTHORIZE AND PLACE ORDER ({formatTaka(grandTotal)})</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
