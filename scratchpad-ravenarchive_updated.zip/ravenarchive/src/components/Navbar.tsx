import React, { useState } from 'react';
import {
  ShoppingBag,
  User as UserIcon,
  Heart,
  Shield,
  Menu,
  X,
  LogOut,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { useStore } from '../context/StoreContext.tsx';
import { formatTaka, FREE_SHIPPING_THRESHOLD } from '../utils/format.ts';

interface NavbarProps {
  onOpenAuth: () => void;
  onOpenAccount: () => void;
  onOpenAdmin: () => void;
  currentView: 'shop' | 'account' | 'admin';
  setCurrentView: (view: 'shop' | 'account' | 'admin') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAuth,
  onOpenAccount,
  onOpenAdmin,
  currentView,
  setCurrentView,
}) => {
  const { currentUser, userProfile, isAdmin, isEmailVerified, logout } = useAuth();
  const { cart, wishlist, setIsCartOpen } = useStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <header className="sticky top-0 z-40 bg-black/85 backdrop-blur-md border-b border-white/10 text-white transition-all">
      {/* Top Banner */}
      <div className="bg-neutral-950 border-b border-white/5 py-1.5 px-4 text-center text-[10px] tracking-widest uppercase font-mono text-neutral-400 flex items-center justify-between">
        <span className="hidden sm:inline">AUTUMN / WINTER 2026 // LIMITED PRODUCTION CAPSULE</span>
        <span className="mx-auto sm:mx-0 font-medium text-neutral-300">
          COMPLIMENTARY GLOBAL COURIER ON ORDERS OVER {formatTaka(FREE_SHIPPING_THRESHOLD)}
        </span>
        <span className="hidden sm:inline text-neutral-500 text-[10px]">EDITION // ARCHIVE</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Mobile menu trigger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-neutral-400 hover:text-white transition-colors"
          aria-label="Toggle navigation menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>

        {/* Brand / Logo */}
        <div className="flex items-center gap-8">
          <button
            onClick={() => {
              setCurrentView('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-2xl sm:text-3xl font-extrabold tracking-[0.28em] uppercase hover:opacity-80 transition-opacity font-mono"
          >
            R A V E N
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-8 text-xs font-mono tracking-widest uppercase text-neutral-300">
            <button
              onClick={() => setCurrentView('shop')}
              className={`hover:text-white transition-colors py-1 ${
                currentView === 'shop' ? 'text-white border-b-2 border-white font-semibold' : ''
              }`}
            >
              Collection
            </button>
            <a
              href="#drops"
              onClick={(e) => {
                if (currentView !== 'shop') {
                  setCurrentView('shop');
                }
              }}
              className="hover:text-white transition-colors py-1"
            >
              Drops
            </a>
            <a
              href="#manifesto"
              onClick={(e) => {
                if (currentView !== 'shop') {
                  setCurrentView('shop');
                }
              }}
              className="hover:text-white transition-colors py-1"
            >
              Lookbook
            </a>
            {isAdmin && (
              <button
                onClick={onOpenAdmin}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-all border text-xs font-mono tracking-wider bg-white/10 hover:bg-white/20 text-white font-semibold border-white/30 ${
                  currentView === 'admin' ? 'ring-1 ring-white' : ''
                }`}
              >
                <Shield className="w-3.5 h-3.5 text-neutral-300" />
                <span>Admin Terminal</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              </button>
            )}
          </nav>
        </div>

        {/* Actions / Utilities */}
        <div className="flex items-center gap-3 sm:gap-5">
          {/* Wishlist trigger */}
          <button
            onClick={() => {
              if (currentUser) {
                setCurrentView('account');
              } else {
                onOpenAuth();
              }
            }}
            className="p-2 text-neutral-400 hover:text-white transition-colors relative"
            title="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlist.length > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-white rounded-full"></span>
            )}
          </button>

          {/* Cart trigger */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="p-2 text-neutral-400 hover:text-white transition-colors relative flex items-center gap-1"
            title="Bag"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartItemCount > 0 && (
              <span className="bg-white text-black text-[10px] font-mono font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartItemCount}
              </span>
            )}
          </button>

          {/* User Auth / Account Dropdown */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 p-1.5 rounded-full border border-white/20 hover:border-white transition-colors bg-neutral-900"
              >
                <img
                  src={
                    currentUser.photoURL ||
                    `https://api.dicebear.com/7.x/shapes/svg?seed=${currentUser.uid}`
                  }
                  alt={currentUser.displayName || 'Customer'}
                   className="w-7 h-7 rounded-full object-cover border border-white/30"
                />
                <span className="hidden lg:inline text-xs font-mono font-medium max-w-[100px] truncate text-neutral-200">
                  {currentUser.displayName?.split(' ')[0] || 'Account'}
                </span>
                {isEmailVerified ? (
                  <CheckCircle className="w-3 h-3 text-emerald-400 hidden sm:inline" />
                ) : (
                  <AlertCircle className="w-3 h-3 text-amber-400 hidden sm:inline" />
                )}
              </button>

              {/* User Dropdown Menu */}
              {userDropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-64 bg-neutral-950 border border-white/20 rounded shadow-2xl py-2 z-50 text-left font-mono"
                  onMouseLeave={() => setUserDropdownOpen(false)}
                >
                  <div className="px-4 py-3 border-b border-white/10">
                    <p className="text-xs text-neutral-400">AUTHENTICATED AS</p>
                    <p className="text-sm font-semibold truncate text-white">
                      {currentUser.displayName || 'Member'}
                    </p>
                    <p className="text-[11px] text-neutral-400 truncate">{currentUser.email}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-[9px] px-2 py-0.5 rounded bg-white/10 text-neutral-300 uppercase tracking-widest border border-white/10">
                        {isAdmin ? 'ADMINISTRATOR' : 'VERIFIED MEMBER'}
                      </span>
                      {isEmailVerified ? (
                        <span className="text-[9px] text-emerald-400 flex items-center gap-0.5">
                          <CheckCircle className="w-2.5 h-2.5" /> Verified
                        </span>
                      ) : (
                        <span className="text-[9px] text-amber-400 flex items-center gap-0.5">
                          <AlertCircle className="w-2.5 h-2.5" /> Unverified
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setCurrentView('account');
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs text-neutral-300 hover:text-white hover:bg-white/10 flex items-center gap-2 transition-colors"
                  >
                    <UserIcon className="w-4 h-4" />
                    Customer Dashboard
                  </button>

                  {isAdmin && (
                    <button
                      onClick={() => {
                        setCurrentView('admin');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-xs text-neutral-300 hover:text-white hover:bg-white/10 flex items-center gap-2 transition-colors border-t border-white/5"
                    >
                      <Shield className="w-4 h-4 text-neutral-300" />
                      Admin Terminal
                    </button>
                  )}

                  <div className="border-t border-white/10 my-1"></div>

                  <button
                    onClick={async () => {
                      setUserDropdownOpen(false);
                      await logout();
                      setCurrentView('shop');
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs text-red-400 hover:text-red-300 hover:bg-white/10 flex items-center gap-2 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-4 py-2 rounded bg-white text-black hover:bg-neutral-200 text-xs font-mono font-semibold tracking-wider uppercase transition-all flex items-center gap-2"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-neutral-950 border-b border-white/15 px-6 py-6 font-mono text-sm tracking-wider uppercase space-y-4">
          <button
            onClick={() => {
              setCurrentView('shop');
              setMobileMenuOpen(false);
            }}
            className="block w-full text-left py-2 text-neutral-300 hover:text-white border-b border-white/5"
          >
            Collection
          </button>
          <button
            onClick={() => {
              if (currentUser) {
                setCurrentView('account');
              } else {
                onOpenAuth();
              }
              setMobileMenuOpen(false);
            }}
            className="block w-full text-left py-2 text-neutral-300 hover:text-white border-b border-white/5"
          >
            Customer Account
          </button>
          {isAdmin && (
            <button
              onClick={() => {
                onOpenAdmin();
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 text-white font-bold flex items-center justify-between border-b border-white/5"
            >
              <span className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-neutral-300" />
                Admin Terminal
              </span>
              <span className="text-[10px] text-emerald-400 font-bold">AUTHORIZED</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
};
