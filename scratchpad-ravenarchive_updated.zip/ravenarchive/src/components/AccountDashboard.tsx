import React, { useState, useEffect } from 'react';
import {
  User,
  Package,
  MapPin,
  Heart,
  Settings,
  LogOut,
  Mail,
  CheckCircle,
  AlertCircle,
  Plus,
  Trash2,
  ExternalLink,
  Shield,
  Loader2,
  Send,
  RefreshCw,
  ShoppingBag
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { useStore } from '../context/StoreContext.tsx';
import { formatTaka, FREE_SHIPPING_THRESHOLD } from '../utils/format.ts';
import { Order, UserAddress, Product } from '../types.ts';
import {
  getOrdersForUser,
  getUserAddresses,
  saveUserAddress,
  deleteUserAddress,
  removeFromWishlist
} from '../services/storeService.ts';

type DashboardTab = 'profile' | 'orders' | 'addresses' | 'wishlist' | 'settings';

interface AccountDashboardProps {
  onBackToShop: () => void;
  onOpenAdmin: () => void;
}

export const AccountDashboard: React.FC<AccountDashboardProps> = ({
  onBackToShop,
  onOpenAdmin,
}) => {
  const {
    currentUser,
    userProfile,
    isAdmin,
    isEmailVerified,
    logout,
    updateProfileData,
    sendVerificationEmail,
    reloadUserStatus
  } = useAuth();
  const { products, wishlist, addToCart, toggleWishlist } = useStore();

  const [activeTab, setActiveTab] = useState<DashboardTab>('profile');
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState<boolean>(true);
  const [addresses, setAddresses] = useState<UserAddress[]>([]);
  const [loadingAddresses, setLoadingAddresses] = useState<boolean>(true);

  // Address Modal State
  const [showAddressModal, setShowAddressModal] = useState<boolean>(false);
  const [recipientName, setRecipientName] = useState('');
  const [street, setStreet] = useState('');
  const [apartment, setApartment] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('United States');
  const [isDefault, setIsDefault] = useState(false);
  const [savingAddress, setSavingAddress] = useState(false);

  // Profile Settings Form
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMessage, setProfileMessage] = useState<string | null>(null);

  // Email Verification Feedback
  const [sendingEmail, setSendingEmail] = useState(false);
  const [verificationMessage, setVerificationMessage] = useState<string | null>(null);
  const [reloadingStatus, setReloadingStatus] = useState(false);

  useEffect(() => {
    if (userProfile) {
      setEditName(userProfile.displayName || '');
      setEditPhone(userProfile.phone || '');
    }
  }, [userProfile]);

  // Load orders and addresses when user is loaded
  useEffect(() => {
    if (currentUser) {
      setLoadingOrders(true);
      getOrdersForUser(currentUser.uid)
        .then((items) => setOrders(items))
        .catch((err) => console.warn('Could not fetch user orders:', err))
        .finally(() => setLoadingOrders(false));

      setLoadingAddresses(true);
      getUserAddresses(currentUser.uid)
        .then((addrs) => setAddresses(addrs))
        .catch((err) => console.warn('Could not fetch user addresses:', err))
        .finally(() => setLoadingAddresses(false));
    }
  }, [currentUser]);

  if (!currentUser) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center font-mono text-white">
        <h2 className="text-2xl font-bold uppercase mb-4">AUTHENTICATION REQUIRED</h2>
        <p className="text-neutral-400 text-sm mb-6">
          Please sign in to access your private customer account.
        </p>
        <button
          onClick={onBackToShop}
          className="px-6 py-3 bg-white text-black font-bold uppercase text-xs"
        >
          Return to Storefront
        </button>
      </div>
    );
  }

  // Handle Resend Verification Email
  const handleResendEmail = async () => {
    setSendingEmail(true);
    setVerificationMessage(null);
    try {
      const res = await sendVerificationEmail();
      setVerificationMessage(res.message);
    } catch (err: any) {
      setVerificationMessage(err.message || 'Failed to dispatch email.');
    } finally {
      setSendingEmail(false);
    }
  };

  const handleCheckStatus = async () => {
    setReloadingStatus(true);
    const verified = await reloadUserStatus();
    setReloadingStatus(false);
    if (verified) {
      setVerificationMessage('Status refreshed: Your email is verified!');
    } else {
      setVerificationMessage('Status checked: Email is still unverified. Please check your inbox and click the verification link.');
    }
  };

  // Handle Save Address
  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingAddress(true);
    try {
      const newAddr: UserAddress = {
        id: `addr-${Date.now()}`,
        userId: currentUser.uid,
        recipientName,
        street,
        apartment,
        city,
        state,
        postalCode,
        country,
        isDefault: isDefault || addresses.length === 0,
        createdAt: new Date().toISOString(),
      };

      await saveUserAddress(currentUser.uid, newAddr);
      setAddresses(prev => [newAddr, ...prev]);
      setShowAddressModal(false);
      // Reset form
      setRecipientName('');
      setStreet('');
      setApartment('');
      setCity('');
      setState('');
      setPostalCode('');
      setIsDefault(false);
    } catch (err: any) {
      alert('Failed to save address: ' + err.message);
    } finally {
      setSavingAddress(false);
    }
  };

  const handleDeleteAddress = async (id: string) => {
    if (!confirm('Remove this saved address?')) return;
    try {
      await deleteUserAddress(currentUser.uid, id);
      setAddresses(prev => prev.filter(a => a.id !== id));
    } catch (err: any) {
      alert('Failed to delete address: ' + err.message);
    }
  };

  // Handle Profile Update
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    setProfileMessage(null);
    try {
      await updateProfileData({
        displayName: editName,
        phone: editPhone,
      });
      setProfileMessage('Account profile updated successfully.');
    } catch (err: any) {
      setProfileMessage('Error: ' + err.message);
    } finally {
      setSavingProfile(false);
    }
  };

  // Filter wishlisted products
  const wishlistedProducts = products.filter(p => wishlist.includes(p.id));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-white font-mono">
      {/* Top Breadcrumb & User Summary */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-8 mb-8 border-b border-white/10 gap-6">
        <div className="flex items-center gap-4">
          <img
            src={currentUser.photoURL || `https://api.dicebear.com/7.x/shapes/svg?seed=${currentUser.uid}`}
            alt={currentUser.displayName || 'Member'}
            className="w-16 h-16 rounded-full border-2 border-white/20 object-cover"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold uppercase tracking-wider">
                {currentUser.displayName || 'RAVEN MEMBER'}
              </h1>
              <span className="text-[10px] px-2 py-0.5 rounded bg-white/10 border border-white/10 uppercase font-semibold">
                {isAdmin ? 'ADMINISTRATOR' : 'CUSTOMER'}
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">{currentUser.email}</p>
            <p className="text-[10px] text-neutral-500 mt-1">UID: {currentUser.uid}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {isAdmin && (
            <button
              onClick={onOpenAdmin}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-xs uppercase tracking-wider font-semibold flex items-center gap-2 transition-colors"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Terminal</span>
            </button>
          )}
          <button
            onClick={onBackToShop}
            className="px-4 py-2 border border-white/20 hover:border-white text-xs uppercase tracking-wider font-semibold transition-colors"
          >
            Storefront
          </button>
          <button
            onClick={async () => {
              await logout();
              onBackToShop();
            }}
            className="px-4 py-2 bg-red-950/60 hover:bg-red-900 border border-red-800 text-red-200 text-xs uppercase tracking-wider font-semibold flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* EMAIL VERIFICATION STATUS BANNER (CRITICAL REQUIREMENT) */}
      {!isEmailVerified ? (
        <div className="mb-8 p-4 bg-amber-950/40 border border-amber-500/50 rounded-none flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-amber-200 uppercase tracking-wider">
                EMAIL NOT YET VERIFIED
              </p>
              <p className="text-xs text-amber-300/80 mt-1 font-sans">
                A verification link was dispatched to <strong>{currentUser.email}</strong>. Please verify your address to secure your account and guarantee release drop notifications.
              </p>
              {verificationMessage && (
                <p className="text-xs text-white font-bold mt-2 bg-black/40 p-2 border border-amber-500/30">
                  {verificationMessage}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleResendEmail}
              disabled={sendingEmail}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {sendingEmail ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Sending...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Resend Verification Email</span>
                </>
              )}
            </button>

            <button
              onClick={handleCheckStatus}
              disabled={reloadingStatus}
              className="px-3 py-2 border border-amber-500/40 hover:border-amber-400 text-amber-200 text-xs font-bold uppercase flex items-center gap-1 transition-colors"
              title="Refresh verification state from Firebase Auth"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${reloadingStatus ? 'animate-spin' : ''}`} />
              <span>Check Status</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="mb-8 p-3 bg-emerald-950/30 border border-emerald-500/30 flex items-center gap-2.5 text-xs text-emerald-300">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>EMAIL VERIFIED // Full account cryptographic access active.</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex border-b border-white/10 mb-8 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('profile')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'profile' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>Profile</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'orders' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('addresses')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'addresses' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <MapPin className="w-3.5 h-3.5" />
          <span>Addresses ({addresses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('wishlist')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'wishlist' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <Heart className="w-3.5 h-3.5" />
          <span>Wishlist ({wishlist.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'settings' ? 'border-white text-white' : 'border-transparent text-neutral-400 hover:text-white'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          <span>Settings</span>
        </button>
      </div>

      {/* TAB 1: PROFILE SUMMARY */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <div className="p-6 bg-neutral-950 border border-white/10">
              <h3 className="text-sm font-bold uppercase tracking-wider mb-4 pb-2 border-b border-white/10">
                CUSTOMER CREDENTIALS
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-neutral-500 uppercase block text-[10px]">DISPLAY NAME</span>
                  <span className="text-neutral-200 font-bold mt-0.5 block">{currentUser.displayName || 'N/A'}</span>
                </div>
                <div>
                  <span className="text-neutral-500 uppercase block text-[10px]">ACCOUNT EMAIL</span>
                  <span className="text-neutral-200 font-bold mt-0.5 block">{currentUser.email}</span>
                </div>
                <div>
                  <span className="text-neutral-500 uppercase block text-[10px]">AUTHENTICATION PROVIDER</span>
                  <span className="text-neutral-200 font-bold mt-0.5 block">Google OAuth 2.0</span>
                </div>
                <div>
                  <span className="text-neutral-500 uppercase block text-[10px]">EMAIL VERIFICATION</span>
                  <span className={`font-bold mt-0.5 block ${isEmailVerified ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {isEmailVerified ? 'Verified' : 'Pending Verification'}
                  </span>
                </div>
                <div>
                  <span className="text-neutral-500 uppercase block text-[10px]">CONTACT PHONE</span>
                  <span className="text-neutral-200 font-bold mt-0.5 block">{userProfile?.phone || 'Not Specified'}</span>
                </div>
                <div>
                  <span className="text-neutral-500 uppercase block text-[10px]">MEMBER REGISTRATION</span>
                  <span className="text-neutral-200 font-bold mt-0.5 block">
                    {userProfile?.createdAt ? new Date(userProfile.createdAt).toLocaleDateString() : 'Active'}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Recent Order Preview */}
            <div className="p-6 bg-neutral-950 border border-white/10">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/10">
                <h3 className="text-sm font-bold uppercase tracking-wider">LATEST ORDER</h3>
                <button
                  onClick={() => setActiveTab('orders')}
                  className="text-xs text-neutral-400 hover:text-white underline underline-offset-4"
                >
                  View All Orders
                </button>
              </div>

              {orders.length === 0 ? (
                <p className="text-xs text-neutral-500">NO TRANSACTION HISTORY YET.</p>
              ) : (
                <div className="text-xs space-y-2">
                  <div className="flex justify-between font-bold">
                    <span>ORDER #{orders[0].id}</span>
                    <span className="uppercase text-emerald-400">{orders[0].status}</span>
                  </div>
                  <p className="text-neutral-400">
                    {new Date(orders[0].createdAt).toLocaleDateString()} — {orders[0].items.length} items ({formatTaka(orders[0].total)})
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Side Card */}
          <div className="space-y-6">
            <div className="p-6 bg-neutral-950 border border-white/10">
              <h3 className="text-sm font-bold uppercase tracking-wider mb-3">TIER PRIVILEGES</h3>
              <ul className="text-xs space-y-3 text-neutral-400">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-white shrink-0 mt-0.5" />
                  <span>Early access to capsule drops and private releases.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-white shrink-0 mt-0.5" />
                  <span>Complimentary worldwide courier on orders above {formatTaka(FREE_SHIPPING_THRESHOLD)}.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-white shrink-0 mt-0.5" />
                  <span>Cryptographically verified Cloud Firestore data storage.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ORDER HISTORY */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          {loadingOrders ? (
            <div className="py-16 text-center text-neutral-400">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
              <span>Loading purchase history from Firestore...</span>
            </div>
          ) : orders.length === 0 ? (
            <div className="p-12 text-center bg-neutral-950 border border-white/10 space-y-3">
              <Package className="w-8 h-8 mx-auto text-neutral-500" />
              <p className="text-sm font-bold">NO PURCHASES RECORDED</p>
              <p className="text-xs text-neutral-400 font-sans">
                You have not placed any orders with this customer account yet.
              </p>
              <button
                onClick={onBackToShop}
                className="mt-4 px-6 py-2.5 bg-white text-black font-bold text-xs uppercase"
              >
                Explore Current Pieces
              </button>
            </div>
          ) : (
            orders.map((order) => (
              <div key={order.id} className="p-6 bg-neutral-950 border border-white/10 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-white/10 gap-2">
                  <div>
                    <span className="text-[10px] text-neutral-500 block">ORDER ID</span>
                    <span className="text-sm font-bold text-white tracking-wider">{order.id}</span>
                  </div>
                  <div className="flex items-center gap-4 text-xs">
                    <div>
                      <span className="text-[10px] text-neutral-500 block">DATE PLACED</span>
                      <span>{new Date(order.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-500 block">TOTAL</span>
                      <span className="font-bold text-white">{formatTaka(order.total)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-neutral-500 block">STATUS</span>
                      <span className={`px-2 py-0.5 uppercase font-bold text-[10px] rounded ${
                        order.status === 'delivered'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-500'
                          : order.status === 'shipped'
                          ? 'bg-blue-950 text-blue-300 border border-blue-500'
                          : order.status === 'processing'
                          ? 'bg-amber-950 text-amber-300 border border-amber-500'
                          : 'bg-neutral-800 text-neutral-200'
                      }`}>
                        {order.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Items in this Order */}
                <div className="space-y-3">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs py-1">
                      <div className="flex items-center gap-3">
                        {item.image && (
                          <img
                            src={item.image}
                            alt=""
                            className="w-10 h-12 object-cover bg-neutral-900 border border-white/10 grayscale"
                          />
                        )}
                        <div>
                          <p className="font-bold text-white">{item.name}</p>
                          <p className="text-[11px] text-neutral-400">
                            Size: {item.size} × Qty: {item.quantity}
                          </p>
                        </div>
                      </div>
                      <span className="font-bold text-neutral-300">{formatTaka(item.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>

                {/* Shipping destination */}
                <div className="pt-3 border-t border-white/5 text-[11px] text-neutral-400">
                  <span className="text-neutral-500 font-bold block mb-0.5">SHIPPING TO:</span>
                  <span>{order.shippingAddress}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 3: SAVED SHIPPING ADDRESSES */}
      {activeTab === 'addresses' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-white/10">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider">SAVED ADDRESSES</h3>
              <p className="text-xs text-neutral-400 mt-0.5 font-sans">
                Manage your delivery destinations for instant checkout.
              </p>
            </div>
            <button
              onClick={() => setShowAddressModal(true)}
              className="px-4 py-2 bg-white text-black text-xs font-bold uppercase flex items-center gap-1.5 hover:bg-neutral-200 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Address</span>
            </button>
          </div>

          {loadingAddresses ? (
            <div className="py-16 text-center text-neutral-400">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
              <span>Loading addresses...</span>
            </div>
          ) : addresses.length === 0 ? (
            <div className="p-12 text-center bg-neutral-950 border border-white/10 space-y-3">
              <MapPin className="w-8 h-8 mx-auto text-neutral-500" />
              <p className="text-sm font-bold">NO ADDRESSES SAVED</p>
              <p className="text-xs text-neutral-400 font-sans">
                Save an address now to accelerate future capsule allocations.
              </p>
              <button
                onClick={() => setShowAddressModal(true)}
                className="mt-4 px-6 py-2 bg-white text-black font-bold text-xs uppercase"
              >
                Add Shipping Address
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {addresses.map((addr) => (
                <div
                  key={addr.id}
                  className="p-5 bg-neutral-950 border border-white/10 flex flex-col justify-between"
                >
                  <div className="text-xs space-y-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-sm text-white">{addr.recipientName}</span>
                      {addr.isDefault && (
                        <span className="text-[9px] px-2 py-0.5 bg-white text-black font-bold">
                          DEFAULT
                        </span>
                      )}
                    </div>
                    <p className="text-neutral-300">{addr.street} {addr.apartment || ''}</p>
                    <p className="text-neutral-400">{addr.city}, {addr.state || ''} {addr.postalCode}</p>
                    <p className="text-neutral-400">{addr.country}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/10 flex justify-end">
                    <button
                      onClick={() => handleDeleteAddress(addr.id)}
                      className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: WISHLIST */}
      {activeTab === 'wishlist' && (
        <div className="space-y-6">
          <div className="pb-4 border-b border-white/10">
            <h3 className="text-sm font-bold uppercase tracking-wider">BOOKMARKED PIECES</h3>
            <p className="text-xs text-neutral-400 mt-0.5 font-sans">
              Pieces you have saved to your private wishlist.
            </p>
          </div>

          {wishlistedProducts.length === 0 ? (
            <div className="p-12 text-center bg-neutral-950 border border-white/10 space-y-3">
              <Heart className="w-8 h-8 mx-auto text-neutral-500" />
              <p className="text-sm font-bold">NO PIECES IN WISHLIST</p>
              <p className="text-xs text-neutral-400 font-sans">
                Browse our seasonal capsule and tap the heart icon on any piece to save it.
              </p>
              <button
                onClick={onBackToShop}
                className="mt-4 px-6 py-2.5 bg-white text-black font-bold text-xs uppercase"
              >
                Browse Storefront
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {wishlistedProducts.map((product) => (
                <div key={product.id} className="p-4 bg-neutral-950 border border-white/10 flex flex-col justify-between">
                  <div>
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="aspect-[3/4] object-cover bg-neutral-900 border border-white/10 grayscale contrast-110 mb-3"
                    />
                    <span className="text-[10px] text-neutral-500 uppercase block">{product.category}</span>
                    <h4 className="text-xs font-bold text-white line-clamp-1">{product.name}</h4>
                    <p className="text-xs font-bold text-neutral-300 mt-1">{formatTaka(product.price)}</p>
                  </div>

                  <div className="mt-4 space-y-2">
                    <button
                      onClick={() => addToCart(product, product.sizes[0] || 'M', 1)}
                      className="w-full py-2 bg-white text-black font-bold text-xs uppercase flex items-center justify-center gap-1.5 hover:bg-neutral-200"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Add to Bag</span>
                    </button>
                    <button
                      onClick={() => toggleWishlist(product.id)}
                      className="w-full py-1.5 border border-white/20 text-neutral-400 hover:text-white text-xs uppercase"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: ACCOUNT SETTINGS */}
      {activeTab === 'settings' && (
        <div className="max-w-2xl bg-neutral-950 border border-white/10 p-6 sm:p-8 space-y-6">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider">ACCOUNT PREFERENCES</h3>
            <p className="text-xs text-neutral-400 mt-0.5 font-sans">
              Update personal identity information synchronized to Cloud Firestore.
            </p>
          </div>

          {profileMessage && (
            <div className="p-3 bg-white/10 border border-white/20 text-xs">
              {profileMessage}
            </div>
          )}

          <form onSubmit={handleUpdateProfile} className="space-y-4 text-xs">
            <div>
              <label className="block text-neutral-400 text-[10px] uppercase mb-1">
                PREFERRED DISPLAY NAME
              </label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
              />
            </div>

            <div>
              <label className="block text-neutral-400 text-[10px] uppercase mb-1">
                CONTACT PHONE NUMBER
              </label>
              <input
                type="tel"
                value={editPhone}
                placeholder="+1 (555) 019-2834"
                onChange={(e) => setEditPhone(e.target.value)}
                className="w-full bg-neutral-900 border border-white/20 px-3 py-2 text-white focus:outline-none focus:border-white"
              />
            </div>

            <div>
              <label className="block text-neutral-400 text-[10px] uppercase mb-1">
                GOOGLE EMAIL (IMMUTABLE)
              </label>
              <input
                type="text"
                disabled
                value={currentUser.email || ''}
                className="w-full bg-neutral-900/50 border border-white/10 px-3 py-2 text-neutral-500 cursor-not-allowed"
              />
            </div>

            <button
              type="submit"
              disabled={savingProfile}
              className="px-6 py-3 bg-white text-black font-bold uppercase tracking-wider text-xs hover:bg-neutral-200 transition-colors disabled:opacity-50"
            >
              {savingProfile ? 'SAVING UPDATES...' : 'SAVE CHANGES'}
            </button>
          </form>
        </div>
      )}

      {/* Modal: Add New Address */}
      {showAddressModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div
            className="w-full max-w-lg bg-neutral-950 border border-white/20 p-6 sm:p-8 font-mono text-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-base font-bold uppercase tracking-wider mb-4 pb-2 border-b border-white/10">
              NEW SHIPPING DESTINATION
            </h3>

            <form onSubmit={handleSaveAddress} className="space-y-4 text-xs">
              <div>
                <label className="block text-[10px] text-neutral-400 mb-1">RECIPIENT NAME *</label>
                <input
                  type="text"
                  required
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/20 px-3 py-2 focus:outline-none focus:border-white"
                />
              </div>

              <div>
                <label className="block text-[10px] text-neutral-400 mb-1">STREET ADDRESS *</label>
                <input
                  type="text"
                  required
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/20 px-3 py-2 focus:outline-none focus:border-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">APARTMENT / SUITE</label>
                  <input
                    type="text"
                    value={apartment}
                    onChange={(e) => setApartment(e.target.value)}
                    className="w-full bg-neutral-900 border border-white/20 px-3 py-2 focus:outline-none focus:border-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">CITY *</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-neutral-900 border border-white/20 px-3 py-2 focus:outline-none focus:border-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">STATE / REGION</label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full bg-neutral-900 border border-white/20 px-3 py-2 focus:outline-none focus:border-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">POSTAL CODE *</label>
                  <input
                    type="text"
                    required
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="w-full bg-neutral-900 border border-white/20 px-3 py-2 focus:outline-none focus:border-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-neutral-400 mb-1">COUNTRY *</label>
                <input
                  type="text"
                  required
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/20 px-3 py-2 focus:outline-none focus:border-white"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="defaultAddressCheck"
                  checked={isDefault}
                  onChange={(e) => setIsDefault(e.target.checked)}
                  className="accent-white"
                />
                <label htmlFor="defaultAddressCheck" className="text-[11px] text-neutral-300 cursor-pointer">
                  Set as default shipping address
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowAddressModal(false)}
                  className="px-4 py-2 border border-white/20 text-neutral-400 hover:text-white text-xs uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingAddress}
                  className="px-6 py-2 bg-white text-black font-bold text-xs uppercase hover:bg-neutral-200 disabled:opacity-50"
                >
                  {savingAddress ? 'Saving...' : 'Save Address'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
