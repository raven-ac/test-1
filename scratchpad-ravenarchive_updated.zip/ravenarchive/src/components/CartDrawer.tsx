import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ArrowRight, ShieldCheck, Tag } from 'lucide-react';
import { useStore } from '../context/StoreContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { validateCoupon, couponDiscount } from '../services/storeService.ts';
import { formatTaka, calcTotals } from '../utils/format.ts';

interface CartDrawerProps {
  onCheckout: () => void;
  onOpenAuth: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onCheckout, onOpenAuth }) => {
  const { cart, isCartOpen, setIsCartOpen, removeFromCart, updateQuantity, cartSubtotal, appliedCoupon, setAppliedCoupon } = useStore();
  const { currentUser } = useAuth();
  const [promoCode, setPromoCode] = useState('');
  const [promoMessage, setPromoMessage] = useState<string | null>(null);
  const [promoLoading, setPromoLoading] = useState(false);

  if (!isCartOpen) return null;

  const handleApplyPromo = async (e: React.FormEvent) => {
    e.preventDefault();
    setPromoLoading(true);
    try {
      const coupon = await validateCoupon(promoCode, cartSubtotal);
      setAppliedCoupon(coupon);
      setPromoMessage(`কুপন প্রয়োগ হয়েছে: ${coupon.code}`);
    } catch (err: any) {
      setAppliedCoupon(null);
      setPromoMessage(err.message || 'কুপন প্রয়োগ করা যায়নি');
    } finally {
      setPromoLoading(false);
    }
  };

  const { discount: discountAmount, shipping, tax, total: grandTotal } = calcTotals(
    cartSubtotal,
    couponDiscount(appliedCoupon, cartSubtotal)
  );

  const handleCheckoutClick = () => {
    if (!currentUser) {
      setIsCartOpen(false);
      onOpenAuth();
      return;
    }
    setIsCartOpen(false);
    onCheckout();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm flex justify-end">
      <div
        className="w-full max-w-md bg-neutral-950 border-l border-white/20 h-full flex flex-col justify-between font-mono text-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-extrabold uppercase tracking-widest">SHOPPING BAG</h2>
            <span className="text-xs text-neutral-400">({cart.length})</span>
          </div>
          <button
            onClick={() => setIsCartOpen(false)}
            className="p-2 text-neutral-400 hover:text-white transition-colors"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Body - Items List */}
        <div className="p-6 overflow-y-auto flex-1 divide-y divide-white/10 space-y-4">
          {cart.length === 0 ? (
            <div className="py-20 text-center text-neutral-500 space-y-3">
              <p className="text-sm">YOUR BAG IS CURRENTLY EMPTY.</p>
              <button
                onClick={() => setIsCartOpen(false)}
                className="text-xs text-white underline underline-offset-4 hover:text-neutral-300"
              >
                BROWSE CAPSULE 09
              </button>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.id} className="pt-4 first:pt-0 flex gap-4">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-24 object-cover bg-neutral-900 border border-white/10 grayscale contrast-110 shrink-0"
                />
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-white line-clamp-1">{item.name}</span>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-neutral-500 hover:text-red-400 transition-colors ml-2"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5">SIZE: {item.size}</p>
                    <p className="text-xs font-bold text-neutral-200 mt-1">{formatTaka(item.price)}</p>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center gap-2 border border-white/20 w-fit px-2 py-0.5 mt-2 bg-neutral-900">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="p-1 hover:text-white text-neutral-400"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-xs px-2">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="p-1 hover:text-white text-neutral-400"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Drawer Footer & Total Calculation */}
        {cart.length > 0 && (
          <div className="p-6 border-t border-white/10 bg-neutral-950 space-y-4">
            {/* Promo Code Input */}
            <form onSubmit={handleApplyPromo} className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
                <input
                  type="text"
                  placeholder="কুপন কোড"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/10 text-white text-xs pl-8 pr-2 py-2 focus:outline-none focus:border-white uppercase"
                />
              </div>
              <button
                type="submit"
                disabled={promoLoading || !promoCode.trim()}
                className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-white transition-colors disabled:opacity-50"
              >
                প্রয়োগ
              </button>
            </form>
            {promoMessage && (
              <p className="text-[10px] text-neutral-300 font-mono tracking-wide">{promoMessage}</p>
            )}

            {/* Price Breakdown */}
            <div className="space-y-1.5 text-xs text-neutral-400 pt-2 border-t border-white/5">
              <div className="flex justify-between">
                <span>SUBTOTAL</span>
                <span className="text-white">{formatTaka(cartSubtotal)}</span>
              </div>
              {discountAmount > 0 && appliedCoupon && (
                <div className="flex justify-between text-emerald-400">
                  <span>ডিসকাউন্ট ({appliedCoupon.code})</span>
                  <span>-{formatTaka(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>ESTIMATED SHIPPING</span>
                <span className="text-white">
                  {shipping === 0 ? 'ফ্রি' : formatTaka(shipping)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>ESTIMATED TAX</span>
                <span className="text-white">{formatTaka(tax)}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-white/10">
                <span>GRAND TOTAL</span>
                <span>{formatTaka(grandTotal)}</span>
              </div>
            </div>

            {/* Checkout Action */}
            <button
              onClick={handleCheckoutClick}
              className="w-full py-4 bg-white text-black font-bold uppercase tracking-[0.2em] text-xs hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2"
            >
              <span>{currentUser ? 'PROCEED TO CHECKOUT' : 'SIGN IN WITH GOOGLE TO CHECKOUT'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[10px] text-neutral-500">
              <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
              <span>ENCRYPTED SECURE FIRESTORE TRANSACTION</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
