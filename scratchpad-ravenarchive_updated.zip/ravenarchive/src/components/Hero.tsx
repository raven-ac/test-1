import React from 'react';
import { ArrowDown, Flame, Compass, Lock } from 'lucide-react';

interface HeroProps {
  onExplore: () => void;
  onOpenAuth: () => void;
  isAuthenticated: boolean;
}

export const Hero: React.FC<HeroProps> = ({ onExplore, onOpenAuth, isAuthenticated }) => {
  return (
    <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden border-b border-white/10 bg-black text-white">
      {/* Background Graphic Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.15),rgba(255,255,255,0))] pointer-events-none" />
      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:32px_32px]" />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-20 flex flex-col items-center">
        {/* Drop Tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/20 bg-white/5 backdrop-blur-md mb-8">
          <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
          <span className="text-[11px] font-mono tracking-[0.25em] uppercase text-neutral-300">
            DROP 09 // OBSIDIAN SILENCE
          </span>
        </div>

        {/* Hero Title */}
        <h1 className="text-4xl sm:text-6xl md:text-8xl font-black uppercase tracking-tight font-mono leading-[0.95] mb-6">
          FORM FOLLOWS <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-neutral-200 to-neutral-500">
            DARKNESS.
          </span>
        </h1>

        <p className="max-w-2xl text-sm sm:text-base md:text-lg text-neutral-400 font-sans font-light tracking-wide mb-10 leading-relaxed">
          High-density textiles, modular hardware, and deconstructed streetwear silhouettes tailored for the contemporary avant-garde. Secure your capsule allocation with authenticated membership.
        </p>

        {/* CTA Actions */}
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
          <button
            onClick={onExplore}
            className="w-full sm:w-auto px-8 py-4 bg-white text-black font-mono font-bold text-xs uppercase tracking-[0.2em] hover:bg-neutral-200 transition-all shadow-xl hover:shadow-white/10"
          >
            Explore Capsule
          </button>

          {!isAuthenticated && (
            <button
              onClick={onOpenAuth}
              className="w-full sm:w-auto px-8 py-4 border border-white/30 hover:border-white text-white font-mono text-xs uppercase tracking-[0.2em] bg-black/40 hover:bg-white/10 transition-all flex items-center justify-center gap-2"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Sign In with Google</span>
            </button>
          )}
        </div>

        {/* Brand Metrics Ticker */}
        <div className="mt-20 pt-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-12 w-full text-left font-mono">
          <div>
            <p className="text-[10px] text-neutral-500 uppercase tracking-widest">ORIGIN</p>
            <p className="text-sm font-semibold text-neutral-200 mt-1">PORTUGAL / JAPAN</p>
          </div>
          <div>
            <p className="text-[10px] text-neutral-500 uppercase tracking-widest">TEXTILE GRADE</p>
            <p className="text-sm font-semibold text-neutral-200 mt-1">600 GSM ARCHIVAL</p>
          </div>
          <div>
            <p className="text-[10px] text-neutral-500 uppercase tracking-widest">HARDWARE</p>
            <p className="text-sm font-semibold text-neutral-200 mt-1">AIRCRAFT TITANIUM</p>
          </div>
          <div>
            <p className="text-[10px] text-neutral-500 uppercase tracking-widest">AUTHENTICATION</p>
            <p className="text-sm font-semibold text-neutral-200 mt-1">GOOGLE OAUTH / CLOUD</p>
          </div>
        </div>
      </div>
    </section>
  );
};
