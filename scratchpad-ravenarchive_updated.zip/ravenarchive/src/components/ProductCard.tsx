import React, { useState } from 'react';
import { Heart, Plus, Check } from 'lucide-react';
import { Product } from '../types.ts';
import { useStore } from '../context/StoreContext.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { formatTaka } from '../utils/format.ts';

interface ProductCardProps {
  product: Product;
  onSelectProduct: (product: Product) => void;
  onOpenAuth: () => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelectProduct,
  onOpenAuth,
}) => {
  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const { currentUser } = useAuth();
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [addedAnimation, setAddedAnimation] = useState<boolean>(false);

  const saved = isWishlisted(product.id);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.stock <= 0) return;
    addToCart(product, selectedSize, 1);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1200);
  };

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    toggleWishlist(product.id);
  };

  return (
    <div
      onClick={() => onSelectProduct(product)}
      className="group relative bg-neutral-950 border border-white/10 hover:border-white/40 transition-all flex flex-col cursor-pointer overflow-hidden"
    >
      {/* Product Image Container */}
      <div className="relative aspect-[3/4] bg-neutral-900 overflow-hidden">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover object-center grayscale contrast-110 group-hover:scale-105 group-hover:grayscale-0 transition-all duration-700 ease-out"
          loading="lazy"
        />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 z-10">
          {product.featured && (
            <span className="bg-white text-black text-[9px] font-mono font-bold tracking-widest uppercase px-2 py-0.5">
              Capsule 09
            </span>
          )}
          {product.stock <= 5 && product.stock > 0 && (
            <span className="bg-amber-500/90 text-black text-[9px] font-mono font-bold tracking-widest uppercase px-2 py-0.5">
              Only {product.stock} Left
            </span>
          )}
          {product.stock <= 0 && (
            <span className="bg-red-950 border border-red-500 text-red-300 text-[9px] font-mono font-bold tracking-widest uppercase px-2 py-0.5">
              Archived
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={handleWishlistClick}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all z-10 ${
            saved
              ? 'bg-white text-black'
              : 'bg-black/60 text-white hover:bg-white hover:text-black'
          }`}
          title={saved ? 'Remove from Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
        </button>

        {/* Quick Add Overlay on Hover for Desktop */}
        <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black via-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col gap-2">
          {/* Size Selectors */}
          <div className="flex items-center justify-center gap-1.5 flex-wrap" onClick={(e) => e.stopPropagation()}>
            {product.sizes.map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`text-[10px] font-mono px-2 py-1 rounded transition-colors ${
                  selectedSize === size
                    ? 'bg-white text-black font-bold'
                    : 'bg-black/70 text-neutral-300 hover:text-white border border-white/20'
                }`}
              >
                {size}
              </button>
            ))}
          </div>

          <button
            onClick={handleQuickAdd}
            disabled={product.stock <= 0}
            className={`w-full py-2.5 text-xs font-mono uppercase tracking-wider font-bold transition-all flex items-center justify-center gap-1.5 ${
              product.stock <= 0
                ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                : addedAnimation
                ? 'bg-emerald-500 text-black'
                : 'bg-white text-black hover:bg-neutral-200'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Allocated</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span>Quick Add ({selectedSize})</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Info Block */}
      <div className="p-4 flex flex-col flex-1 justify-between font-mono bg-neutral-950">
        <div>
          <span className="text-[10px] text-neutral-500 uppercase tracking-widest block mb-1">
            {product.category}
          </span>
          <h3 className="text-sm font-semibold tracking-wide text-white group-hover:text-neutral-300 transition-colors line-clamp-1">
            {product.name}
          </h3>
        </div>

        <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between">
          <span className="text-sm font-bold text-neutral-100">{formatTaka(product.price)}</span>
          <span className="text-[10px] text-neutral-500 uppercase">
            {product.stock > 0 ? `${product.stock} Units` : 'Out of Stock'}
          </span>
        </div>
      </div>
    </div>
  );
};
