import React from 'react';
import { ArrowUpRight, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onOpenAuth: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAuth }) => {
  return (
    <footer className="border-t border-white/10 bg-black text-white font-mono text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand Manifesto */}
          <div className="md:col-span-2 space-y-4">
            <span className="text-2xl font-black tracking-[0.25em] uppercase block">
              R A V E N
            </span>
            <p className="font-sans text-neutral-400 text-xs sm:text-sm max-w-md leading-relaxed">
              Monochrome avant-garde garment design. Engineered with brutalist precision and archival longevity. Cryptographically integrated with Google AI Studio and Cloud Firestore.
            </p>
            <div className="flex items-center gap-2 text-[10px] text-neutral-500 pt-2">
              <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
              <span>AUTHENTICATED CUSTOMER ARCHIVE // ZERO-TRUST ACCESS</span>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-[10px] uppercase tracking-widest text-neutral-500 font-bold">
              NAVIGATION
            </h4>
            <ul className="space-y-2 text-neutral-400">
              <li>
                <a href="#collection" className="hover:text-white transition-colors">
                  Current Collection
                </a>
              </li>
              <li>
                <a href="#drops" className="hover:text-white transition-colors">
                  Drop Schedule
                </a>
              </li>
              <li>
                <button onClick={onOpenAuth} className="hover:text-white transition-colors">
                  Customer Sign-In
                </button>
              </li>
            </ul>
          </div>

          {/* Legal / Security */}
          <div className="space-y-3">
            <h4 className="text-[10px] uppercase tracking-widest text-neutral-500 font-bold">
              SYSTEM
            </h4>
            <ul className="space-y-2 text-neutral-400">
              <li>Google OAuth 2.0 Auth</li>
              <li>Cloud Firestore Database</li>
              <li>Role-Based Access Control</li>
              <li>Attribute-Based Security Rules</li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-[11px] text-neutral-500 gap-4">
          <p>© 2026 RAVEN CLOTHING INC. ALL RIGHTS RESERVED.</p>
          <div className="flex items-center gap-6">
            <span>TERMS OF ENGAGEMENT</span>
            <span>PRIVACY DISCLOSURE</span>
            <span>DISPATCH ARCHIVE</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
