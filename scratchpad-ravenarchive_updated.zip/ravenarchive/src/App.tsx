/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { StoreProvider } from './context/StoreContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { ProductGrid } from './components/ProductGrid.tsx';
import { ProductModal } from './components/ProductModal.tsx';
import { CartDrawer } from './components/CartDrawer.tsx';
import { CheckoutModal } from './components/CheckoutModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { AccountDashboard } from './components/AccountDashboard.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import { Footer } from './components/Footer.tsx';
import { Product } from './types.ts';
import { CheckCircle2, PackageCheck } from 'lucide-react';

function MainLayout() {
  const { currentUser, isAdmin } = useAuth();
  const [currentView, setCurrentView] = useState<'shop' | 'account' | 'admin'>('shop');

  // Modals & Drawers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);

  // Order Confirmation Toast
  const [recentOrderId, setRecentOrderId] = useState<string | null>(null);
  const [recentOrderTotal, setRecentOrderTotal] = useState<number>(0);

  const handleOrderSuccess = (orderId: string, total: number) => {
    setCheckoutModalOpen(false);
    setRecentOrderId(orderId);
    setRecentOrderTotal(total);
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col font-sans selection:bg-white selection:text-black">
      {/* Navigation Bar */}
      <Navbar
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenAccount={() => setCurrentView('account')}
        onOpenAdmin={() => setCurrentView('admin')}
        currentView={currentView}
        setCurrentView={setCurrentView}
      />

      {/* Order Success Floating Notification */}
      {recentOrderId && (
        <div className="fixed bottom-6 right-6 z-50 bg-neutral-950 border-2 border-emerald-500/80 p-5 shadow-2xl font-mono max-w-sm">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-xs">
              <p className="font-bold text-white uppercase">ORDER CONFIRMED</p>
              <p className="text-neutral-300 mt-1">
                Allocation registered in Cloud Firestore as <strong>#{recentOrderId}</strong>.
              </p>
              <a
                href={`/pay/${recentOrderId}?amount=${recentOrderTotal}`}
                className="mt-3 block text-center px-3 py-2 bg-[#e2136e] text-white font-bold text-[11px]"
              >
                বিকাশে পেমেন্ট করুন →
              </a>
              <div className="mt-3 flex items-center gap-2">
                <button
                  onClick={() => {
                    setRecentOrderId(null);
                    setCurrentView('account');
                  }}
                  className="px-3 py-1 bg-white text-black font-bold uppercase text-[10px]"
                >
                  View in Order History
                </button>
                <button
                  onClick={() => setRecentOrderId(null)}
                  className="px-2 py-1 text-neutral-400 hover:text-white text-[10px]"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Active View Content */}
      <main className="flex-1">
        {currentView === 'shop' && (
          <>
            <Hero
              onExplore={() => {
                const el = document.getElementById('collection');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              onOpenAuth={() => setAuthModalOpen(true)}
              isAuthenticated={Boolean(currentUser)}
            />

            <ProductGrid
              onSelectProduct={(p) => setSelectedProduct(p)}
              onOpenAuth={() => setAuthModalOpen(true)}
            />

            {/* Architectural Drops Section */}
            <section id="drops" className="border-t border-white/10 bg-neutral-950 py-20 font-mono">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-2xl">
                  <span className="text-[10px] text-neutral-500 uppercase tracking-widest block mb-1">
                    SEASONAL ALLOCATION RELEASE
                  </span>
                  <h3 className="text-3xl font-extrabold uppercase tracking-tight text-white mb-4">
                    ARCHIVAL CAPSULE PIPELINE
                  </h3>
                  <p className="text-neutral-400 text-xs sm:text-sm font-sans mb-8 leading-relaxed">
                    All drops are manufactured in numbered micro-batches. Registered customer members receive early cryptographic reservation keys prior to public showroom opening.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-6 bg-black border border-white/10 space-y-2">
                    <span className="text-[10px] text-neutral-500 block">DROP 09 // CURRENT</span>
                    <h4 className="text-sm font-bold text-white uppercase">OBSIDIAN SILENCE</h4>
                    <p className="text-xs text-neutral-400 font-sans">
                      Waterproof memory nylon parkas, 600 GSM distressed French terry hoodies, and articulated cargos.
                    </p>
                    <span className="text-[10px] text-emerald-400 block font-bold pt-2">STATUS: ALLOCATING NOW</span>
                  </div>

                  <div className="p-6 bg-black border border-white/10 space-y-2">
                    <span className="text-[10px] text-neutral-500 block">DROP 10 // UPCOMING</span>
                    <h4 className="text-sm font-bold text-white uppercase">MONOLITH SHADOW</h4>
                    <p className="text-xs text-neutral-400 font-sans">
                      Brutalist shearling bombers, boiled wool overcoats, and titanium-hardware accessories.
                    </p>
                    <span className="text-[10px] text-amber-400 block font-bold pt-2">STATUS: MEMBERS PREVIEW</span>
                  </div>

                  <div className="p-6 bg-black border border-white/10 space-y-2">
                    <span className="text-[10px] text-neutral-500 block">DROP 11 // ARCHIVE</span>
                    <h4 className="text-sm font-bold text-white uppercase">KINETIC DRAPE</h4>
                    <p className="text-xs text-neutral-400 font-sans">
                      Deconstructed Japanese linen tailoring and technical footwear collaborations.
                    </p>
                    <span className="text-[10px] text-neutral-400 block font-bold pt-2">STATUS: DEVELOPMENT</span>
                  </div>
                </div>
              </div>
            </section>
          </>
        )}

        {currentView === 'account' && (
          <AccountDashboard
            onBackToShop={() => setCurrentView('shop')}
            onOpenAdmin={() => setCurrentView('admin')}
          />
        )}

        {currentView === 'admin' && (
          <AdminDashboard
            onBackToShop={() => setCurrentView('shop')}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}
      </main>

      {/* Global Modals & Drawers */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      <CartDrawer
        onCheckout={() => setCheckoutModalOpen(true)}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      <CheckoutModal
        isOpen={checkoutModalOpen}
        onClose={() => setCheckoutModalOpen(false)}
        onOrderSuccess={handleOrderSuccess}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />

      {/* Footer */}
      <Footer
        onOpenAuth={() => setAuthModalOpen(true)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <StoreProvider>
        <MainLayout />
      </StoreProvider>
    </AuthProvider>
  );
}
