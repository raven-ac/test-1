import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  browserLocalPersistence,
  setPersistence,
  sendEmailVerification
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../firebase/config.ts';
import { UserProfile, UserRole } from '../types.ts';
import { handleFirestoreError, OperationType } from '../firebase/errors.ts';

// Bootstrapped authorized administrator email
export const BOOTSTRAP_ADMIN_EMAIL = "a.mdnuhad534@gmail.com";

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  loading: boolean;
  authError: string | null;
  isEmailVerified: boolean;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  clearAuthError: () => void;
  updateProfileData: (data: Partial<UserProfile>) => Promise<void>;
  refreshProfile: () => Promise<void>;
  sendVerificationEmail: () => Promise<{ success: boolean; message: string }>;
  reloadUserStatus: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isEmailVerified, setIsEmailVerified] = useState<boolean>(false);

  // Set persistent login sessions
  useEffect(() => {
    setPersistence(auth, browserLocalPersistence).catch((err) => {
      console.warn('Failed to set local auth persistence:', err);
    });
  }, []);

  const syncUserProfile = async (user: User) => {
    try {
      const userRef = doc(db, 'users', user.uid);
      let docSnap;
      try {
        docSnap = await getDoc(userRef);
      } catch (err) {
        console.warn('Could not read user profile from Firestore, constructing fallback:', err);
      }

      setIsEmailVerified(Boolean(user.emailVerified));

      let isUserAdmin = Boolean(
        user.email &&
        user.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()
      );

      // Check if user email is present in the admin_emails collection
      if (!isUserAdmin && user.email) {
        try {
          const adminEmailDoc = await getDoc(doc(db, 'admin_emails', user.email.toLowerCase()));
          if (adminEmailDoc.exists()) {
            isUserAdmin = true;
          }
        } catch (err) {
          console.warn('Could not check admin_emails collection:', err);
        }
      }

      // Check if user UID is present in /admins collection
      if (!isUserAdmin) {
        try {
          const adminUidDoc = await getDoc(doc(db, 'admins', user.uid));
          if (adminUidDoc.exists()) {
            isUserAdmin = true;
          }
        } catch {
          // ignore
        }
      }

      setIsAdmin(isUserAdmin);

      if (docSnap && docSnap.exists()) {
        const data = docSnap.data() as UserProfile;
        if (isUserAdmin && data.role !== 'admin') {
          data.role = 'admin';
          try {
            await updateDoc(userRef, { role: 'admin', updatedAt: new Date().toISOString() });
          } catch {
            // ignore
          }
        }
        setUserProfile(data);
        if (data.role === 'admin' || isUserAdmin) {
          setIsAdmin(true);
        }
      } else {
        // Automatic account creation on first Google sign-in
        const newProfile: UserProfile = {
          id: user.uid,
          email: user.email || '',
          displayName: user.displayName || user.email?.split('@')[0] || 'RAVEN Member',
          photoURL: user.photoURL || `https://api.dicebear.com/7.x/shapes/svg?seed=${user.uid}`,
          role: isUserAdmin ? 'admin' : 'customer',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        try {
          await setDoc(userRef, newProfile);
          if (isUserAdmin) {
            try {
              await setDoc(doc(db, 'admins', user.uid), {
                id: user.uid,
                email: user.email,
                createdAt: new Date().toISOString()
              });
            } catch {
              // Rule might guard admin doc
            }
          }

          // If email is not yet verified on initial registration, dispatch verification email automatically
          if (!user.emailVerified) {
            try {
              await sendEmailVerification(user);
              console.log('Verification email sent to:', user.email);
            } catch (err) {
              console.warn('Automatic verification email failed or rate limited:', err);
            }
          }
        } catch (err) {
          console.warn('Error saving initial user profile:', err);
        }
        setUserProfile(newProfile);
      }
    } catch (error) {
      console.error('Error syncing user profile:', error);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setLoading(true);
      if (user) {
        setCurrentUser(user);
        setIsEmailVerified(Boolean(user.emailVerified));
        await syncUserProfile(user);
      } else {
        setCurrentUser(null);
        setUserProfile(null);
        setIsAdmin(false);
        setIsEmailVerified(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    setAuthError(null);
    setLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        setIsEmailVerified(Boolean(result.user.emailVerified));
        await syncUserProfile(result.user);
      }
    } catch (err: any) {
      let message = 'An unexpected error occurred during Google sign-in.';
      if (err.code === 'auth/popup-closed-by-user') {
        message = 'Google sign-in popup was closed before completing.';
      } else if (err.code === 'auth/cancelled-popup-request') {
        message = 'Another sign-in request is already active. Please try again.';
      } else if (err.code === 'auth/unauthorized-domain') {
        message = `Unauthorized Domain: The current domain (${window.location.hostname}) is not yet allowlisted in your Firebase Console under Authentication > Settings > Authorized domains.`;
      } else if (err.code === 'auth/popup-blocked') {
        message = 'The sign-in popup was blocked by your browser. Please permit popups for this site.';
      } else if (err.message) {
        message = err.message;
      }
      setAuthError(message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setAuthError(null);
    try {
      await signOut(auth);
      setCurrentUser(null);
      setUserProfile(null);
      setIsAdmin(false);
      setIsEmailVerified(false);
    } catch (err: any) {
      setAuthError(err.message || 'Failed to sign out.');
      throw err;
    }
  };

  const sendVerificationEmail = async (): Promise<{ success: boolean; message: string }> => {
    if (!currentUser) {
      throw new Error('No authenticated user session found.');
    }
    try {
      await sendEmailVerification(currentUser);
      return { success: true, message: `Verification link successfully dispatched to ${currentUser.email}. Check your inbox or spam folder.` };
    } catch (err: any) {
      if (err.code === 'auth/too-many-requests') {
        return { success: false, message: 'Too many requests. Please wait a minute before requesting another verification email.' };
      }
      return { success: false, message: err.message || 'Failed to dispatch verification email.' };
    }
  };

  const reloadUserStatus = async (): Promise<boolean> => {
    if (!currentUser) return false;
    try {
      await currentUser.reload();
      const updatedUser = auth.currentUser;
      if (updatedUser) {
        setCurrentUser(updatedUser);
        setIsEmailVerified(Boolean(updatedUser.emailVerified));
        return Boolean(updatedUser.emailVerified);
      }
      return false;
    } catch (err) {
      console.warn('Failed to reload user status:', err);
      return isEmailVerified;
    }
  };

  const updateProfileData = async (data: Partial<UserProfile>) => {
    if (!currentUser) throw new Error('User not authenticated.');
    const userRef = doc(db, 'users', currentUser.uid);
    const now = new Date().toISOString();
    const cleanUpdates = {
      ...data,
      updatedAt: now,
    };
    try {
      await updateDoc(userRef, cleanUpdates);
      setUserProfile(prev => prev ? { ...prev, ...cleanUpdates } : null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  const refreshProfile = async () => {
    if (currentUser) {
      await syncUserProfile(currentUser);
    }
  };

  const clearAuthError = () => setAuthError(null);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isAdmin,
        loading,
        authError,
        isEmailVerified,
        loginWithGoogle,
        logout,
        clearAuthError,
        updateProfileData,
        refreshProfile,
        sendVerificationEmail,
        reloadUserStatus,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

