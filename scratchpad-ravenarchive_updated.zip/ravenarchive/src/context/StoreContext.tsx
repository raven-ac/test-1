import React, { createContext, useContext, useEffect, useState } from 'react';
import { Product, CartItem, Coupon } from '../types.ts';
import { getProducts, getUserWishlist, addToWishlist, removeFromWishlist } from '../services/storeService.ts';
import { useAuth } from './AuthContext.tsx';

interface StoreContextType {
  products: Product[];
  loadingProducts: boolean;
  cart: CartItem[];
  wishlist: string[];
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  addToCart: (product: Product, size: string, quantity?: number) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, quantity: number) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => Promise<void>;
  isWishlisted: (productId: string) => boolean;
  refreshProducts: () => Promise<void>;
  cartSubtotal: number;
  appliedCoupon: Coupon | null;
  setAppliedCoupon: (coupon: Coupon | null) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState<boolean>(true);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('raven_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  // Sync cart with localStorage
  useEffect(() => {
    try {
      localStorage.setItem('raven_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  // Load products
  const loadProducts = async () => {
    setLoadingProducts(true);
    try {
      const items = await getProducts();
      setProducts(items);
    } catch (err) {
      console.error('Failed to load products:', err);
    } finally {
      setLoadingProducts(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  // Load user wishlist when authenticated
  useEffect(() => {
    if (currentUser) {
      getUserWishlist(currentUser.uid)
        .then(ids => setWishlist(ids))
        .catch(err => console.warn('Could not load user wishlist:', err));
    } else {
      setWishlist([]);
    }
  }, [currentUser]);

  const addToCart = (product: Product, size: string, quantity = 1) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.productId === product.id && item.size === size);
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity
        };
        return next;
      } else {
        const newItem: CartItem = {
          id: `${product.id}-${size}-${Date.now()}`,
          productId: product.id,
          name: product.name,
          price: product.price,
          image: product.images[0] || '',
          size,
          quantity,
          category: product.category,
        };
        return [...prev, newItem];
      }
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.id !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart(prev => prev.map(item => item.id === cartItemId ? { ...item, quantity } : item));
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  const toggleWishlist = async (productId: string) => {
    const isSaved = wishlist.includes(productId);
    if (isSaved) {
      setWishlist(prev => prev.filter(id => id !== productId));
      if (currentUser) {
        try {
          await removeFromWishlist(currentUser.uid, productId);
        } catch (err) {
          console.warn('Failed to remove from remote wishlist:', err);
        }
      }
    } else {
      setWishlist(prev => [...prev, productId]);
      if (currentUser) {
        try {
          await addToWishlist(currentUser.uid, productId);
        } catch (err) {
          console.warn('Failed to add to remote wishlist:', err);
        }
      }
    }
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  const cartSubtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return (
    <StoreContext.Provider
      value={{
        products,
        loadingProducts,
        cart,
        wishlist,
        isCartOpen,
        setIsCartOpen,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        toggleWishlist,
        isWishlisted,
        refreshProducts: loadProducts,
        cartSubtotal,
        appliedCoupon,
        setAppliedCoupon,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
